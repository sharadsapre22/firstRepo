const TreatmentService = {
  getDesignIndex(arrDesigns, designId) {
    return arrDesigns.findIndex(item => item.designId === designId);
  }
};

export default TreatmentService;
