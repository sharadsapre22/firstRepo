const SafetyRegulatoryService = {
  getDesignIndex(arrDesigns, designId) {
    return arrDesigns.findIndex(item => item.designId === designId);
  }
};

export default SafetyRegulatoryService;
