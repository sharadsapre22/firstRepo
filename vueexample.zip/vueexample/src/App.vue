<template>
  <div id="app">
    <b-row id="app-r0">
      <b-col id="app-r0c0">
        <PageHeader id="app-pgheader" />
      </b-col>
    </b-row>
    <b-row id="app-r1">
      <b-col id="app-r1c0" class="pr-0">
        <div id="app-cont">
          <router-view />
        </div>
      </b-col>
    </b-row>
    <b-row id="app-r2" class="mb-5 pb-3">
      <b-col id="app-r2c0">
        <PageFooter id="app-pgfooter" />
      </b-col>
    </b-row>
  </div>
</template>

<script>
// @ is an alias to /src
import PageHeader from "@/components/PageHeader.vue";
import PageFooter from "@/components/PageFooter.vue";

export default {
  name: "App",
  components: {
    PageHeader,
    PageFooter
  }
};
</script>

<style scoped>
.row {
  margin-right: 0px;
}
</style>
