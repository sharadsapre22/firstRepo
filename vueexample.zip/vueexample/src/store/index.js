import Vue from "vue";
import Vuex from "vuex";

import accrualmgmt from "@/store/modules/module-accrual-management";
import designs from "@/store/modules/designs";
import biostats from "@/store/modules/module-biostats";
import safetyregulatory from "@/store/modules/module-safety-regulatory";
import commercial from "@/store/modules/module-commercial";
import treatmentarms from "@/store/modules/module-treatment";
import regulatory from "@/store/modules/module-regulatory";
import studydesign from "@/store/modules/module-study-design";

Vue.use(Vuex);

export default new Vuex.Store({
  modules: {
    accrualmgmt,
    designs,
    biostats,
    safetyregulatory,
    commercial,
    treatmentarms,
    regulatory,
    studydesign
  }
});
