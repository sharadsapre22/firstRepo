import axios from "axios";
import { saveAs } from "file-saver";
import ModuleHelpService from "@/utils/moduleHelpService";

const state = {
  advisorinputs: {
    // Design Advisor inputs
    goals: [],
    purpose: "",
    recommendations: [],
    selectdesign: {}
  },
  designs: {
    // Input Advisor inputs
    studydesign: {},
    treatment: {
      treatmentarms: {}
    },
    patients: {
      survmodel: {},
      dropoutratemodel: {},
      maxfollowuptime: {}
    },
    commercial: {},
    safetyregulatory: {},
    regulatory: {},

    accrandmanagement: {},
    biostats: [],
    csvdata: "",
    csvfilename: ""
  }
};

const getters = {
  advisorinputs: state => state.advisorinputs,
  designs: state => state.designs
};

const actions = {
  selectGoals({ commit }, selectParameters) {
    commit("selectGoals", selectParameters);
  },
  selectPurpose({ commit }, selectParameters) {
    commit("selectPurpose", selectParameters);
  },
  selectRecommendations({ commit }, updatedDesign) {
    commit("selectRecommendations", updatedDesign);
  },
  updateBioStats({ commit }, updatedDesign) {
    commit("updateBioStats", updatedDesign);
  },
  updateSeedParams({ commit }, updatedSeedParams) {
    commit("updateSeedParams", updatedSeedParams);
  },
  updateDesign({ commit }, csvData) {
    commit("updateDesign", csvData);
  },
  // eslint-disable-next-line no-unused-vars
  async simulateDesign({ commit }, data) {
    const response = await axios.post(
      "http://54.92.166.160:3999/api/operations",
      //"http://ec2-3-93-63-250.compute-1.amazonaws.com:3999/api/operations",
      data.json
    );
    commit("simulateDesign", {
      result: response.data.result,
      biostats: data.biostats,
      safetyregulatory: data.safetyregulatory,
      commercial: data.commercial,
      treatmentarms: data.treatmentarms,
      regulatory: data.regulatory,
      studydesign: data.studydesign,
      accrualmgmt: data.accrualmgmt
    });
  }
};

const mutations = {
  selectPurpose(state, purpose) {
    state.advisorinputs.purpose = purpose;
  },
  selectGoals(state, selectParameters) {
    state.advisorinputs.goals = Array.from(selectParameters);
  },
  selectRecommendations(state, recommendations) {
    state.advisorinputs.recommendations = recommendations;
  },
  updateBioStats(state, updatedDesign) {
    state.designs.biostats = updatedDesign;
  },
  updateSeedParams(state, updatedSeedParams) {
    for (let i = 0; i < state.designs.biostats.length; i++) {
      state.designs.biostats[i].seed = updatedSeedParams.seed;
      state.designs.biostats[i].seedtype = updatedSeedParams.seedType;
    }
  },
  updateDesign(state, data) {
    state.designs.csvfilename = data.csvfilename;
    if (data.csvdata.length === 0) state.designs.csvdata = "";
    else {
      var csvDataCols = data.csvdata[0].split(",");
      var csvData = data.csvdata[1].split(",");

      // Patient & Endpoints
      // ------------------
      // Allocation Ratio
      let index = csvDataCols.findIndex(item => item === "AllocRatio");
      state.designs.patients.allocratio = csvData[index];

      // Survival Model Name
      index = csvDataCols.findIndex(item => item === "SurvModel");
      state.designs.patients.survmodel.modelname = csvData[index];

      // Survival Input Method
      index = csvDataCols.findIndex(item => item === "SurvMethod");
      state.designs.patients.survmodel.inputmethod = csvData[index];

      // Median Survival Control
      index = csvDataCols.findIndex(item => item === "SurvMedCTRL");
      state.designs.patients.survmodel.medictrl = csvData[index];

      // Median Survival Treatment
      index = csvDataCols.findIndex(item => item === "SurvMedTRTM");
      state.designs.patients.survmodel.meditrt = csvData[index];

      // Median Survival Hazard Ratio
      index = csvDataCols.findIndex(item => item === "SurvHR");
      state.designs.patients.survmodel.hazardratio = csvData[index];

      // Dropout Model Name
      index = csvDataCols.findIndex(item => item === "DropoutModel");
      state.designs.patients.dropoutratemodel.modelname = csvData[index];

      // Dropout Method
      index = csvDataCols.findIndex(item => item === "DropoutMethod");
      state.designs.patients.dropoutratemodel.inputmethod = csvData[index];

      // Dropout Ctrl
      index = csvDataCols.findIndex(item => item === "DropoutCTRLVal");
      state.designs.patients.dropoutratemodel.probctrl = csvData[index];

      // Dropout Ctrl
      index = csvDataCols.findIndex(item => item === "DropoutTRTMVal");
      state.designs.patients.dropoutratemodel.probtrt = csvData[index];

      // By Time
      index = csvDataCols.findIndex(item => item === "DropoutByTime");
      state.designs.patients.dropoutratemodel.bytime = csvData[index];

      // Followup Method
      index = csvDataCols.findIndex(item => item === "FollowUPMethod");
      state.designs.patients.maxfollowuptime.method = csvData[index];

      // Followup Period For Fixed
      index = csvDataCols.findIndex(item => item === "FixedFollowUpTime");
      state.designs.patients.maxfollowuptime.timeinmonths = csvData[index];
    }
  },
  simulateDesign(state, jdata) {
    let csv =
      "NumIntrimAnalysis,TimeUnit,trtname,ctrlname,AllocRatio,SurvModel,SurvMethod,SurvMedCTRL,SurvMedTRTM,SurvHR,DropoutModel,DropoutMethod,DropoutCTRLVal,DropoutTRTMVal,DropoutByTime,FollowUPMethod,FixedFollowUpTime,NumOfPatients,FirstPatientInDate,AvgPatientsEnrolled,RandomizationType,Hypothesis,TestType,TailType,fixateachlook,NumOfEvents,Alpha,TestStat,NumOfSims,AvgCostPerPatient,DevelopmentCost,MaxTrialCost,HzdRatioLimit,RemainingPatentLifeAStartOftheTrial,RemainingPatentLife,PeakNetRevenue,DiscountRatePerc,RegulatoryReviewPeriod,ProbabilityofApproval,Person-YearsExposureC01_NoOfPatients,Person-YearsExposureC01_Years,Person-YearsExposureC02_NoOfPatients,Person-YearsExposureC02_Years,RandNum,SimSeed,AvgPower,AverageSampleSize,AverageEvents,AverageStudyDuration,AverageAccrualDuration,AverageMedianFollowupTime,Boundary,TimeTakenByEngine,SeedValue,StudyEndDate,StudyCost,TotalStudyCost,TotalDiscountedStudyCost,TotalSales,TotalDiscountedSales,NPV,ProbabilityOfSuccess,ENPV\r\n";

    let designs = state.designs;

    csv += jdata.studydesign.numinterimanalysis + ",";
    csv += jdata.studydesign.timeunit + ",";
    csv += jdata.treatmentarms.treatment + ",";
    csv += jdata.treatmentarms.control + ",";

    // AllocRatio,SurvModel,SurvMethod,SurvMedCTRL,SurvMedTRTM,SurvHR
    csv += designs.patients.allocratio + ",";
    csv += designs.patients.survmodel.modelname + ",";
    csv += designs.patients.survmodel.inputmethod + ",";
    csv += designs.patients.survmodel.medictrl + ",";
    csv += designs.patients.survmodel.meditrt + ",";
    csv += designs.patients.survmodel.hazardratio + ",";

    // DropoutModel,DropoutMethod,DropoutCTRLVal,DropoutTRTMVal,DropoutByTime,FollowUPMethod,FixedFollowUpTime
    csv += designs.patients.dropoutratemodel.modelname + ",";
    csv += designs.patients.dropoutratemodel.inputmethod + ",";
    csv += designs.patients.dropoutratemodel.probctrl + ",";
    csv += designs.patients.dropoutratemodel.probtrt + ",";
    csv += designs.patients.dropoutratemodel.bytime + ",";
    csv += designs.patients.maxfollowuptime.method + ",";
    csv += designs.patients.maxfollowuptime.timeinmonths + ",";

    //NumOfPatients,FirstPatientInDate,AvgPatientsEnrolled,RandomizationType,Hypothesis,TestType,TailType,fixateachlook,

    csv += jdata.accrualmgmt.noofPatients + ",";
    csv += jdata.accrualmgmt.firstPatientInDate + ",";
    csv += jdata.accrualmgmt.avgPatientsPerTimeUnit + ",";
    csv += jdata.accrualmgmt.randomizationType + ",";
    csv += jdata.biostats.hypothesis + ",";
    csv += jdata.biostats.testtype + ",";
    csv +=
      jdata.biostats.tailtype === "Left-tail"
        ? "Left Tailed,"
        : "Right Tailed,";

    csv += jdata.biostats.fixateachlook + ",";

    //NumOfEvents,Alpha,TestStat,NumOfSims,AvgCostPerPatient,DevelopmentCost,MaxTrialCost,HzdRatioLimit,

    csv += jdata.biostats.totalnoofevents + ",";
    csv += jdata.biostats.typeIerror + ",";
    csv += jdata.biostats.teststatistics + ",";
    csv += jdata.biostats.numsimulations + ",";

    //Commercial
    //-------------------------------
    csv += jdata.commercial.avgCostPerPatient + ",";
    csv += jdata.commercial.developmentCost + ",";
    csv += jdata.commercial.maxTrialCost + ",";
    csv += jdata.commercial.hazardRatioLimit + ",";

    //RemainingPatentLife,PeakNetRevenue,DiscountRatePerc,RegulatoryReviewTime,ProbabilityofApproval ,

    csv += jdata.commercial.patentLifeAtTrialStart + ",";
    csv += jdata.result.output.remainingPatentLife + ",";
    csv += jdata.commercial.peakNetRevenue + ",";
    csv += jdata.commercial.discountRate + ",";

    //Regulatory
    //-------------------------------
    csv += jdata.regulatory.regulatoryReviewPeriod + ",";
    csv += jdata.regulatory.probRegulatoryApproval + ",";

    ////Person-YearsExposureC01_NoOfPatients,Person-YearsExposureC01_Years,Person-YearsExposureC02_NoOfPatients,
    //Person-YearsExposureC02_Years,RandNum,SimSeed
    //Safety & Regulatory
    //-------------------------------
    csv += jdata.safetyregulatory.patientOne + ",";
    csv += jdata.safetyregulatory.timeOne + ",";
    csv += jdata.safetyregulatory.patientTwo + ",";
    csv += jdata.safetyregulatory.timeTwo + ",";

    //Random Fixed / Clock
    csv += jdata.biostats.seedtype + ",";
    //Seed
    csv += jdata.biostats.seed + ",";
    //Output
    //AvgPower,AverageSampleSize,AverageEvents,AverageStudyDuration,AverageAccrualDuration,AverageMedianFollowupTime,Boundary,TimeTakenByEngine,
    // SeedValue,StudyEndDate,StudyCost,TotalStudyCost,TotalDiscountedStudyCost,TotalSales,TotalDiscountedSales
    //,NPV,ProbabilityOfSuccess,ENPV
    csv += jdata.result.output.avgPower + ",";
    csv += jdata.result.output.ss + ",";
    csv += jdata.result.output.events + ",";
    csv += jdata.result.output.studyduration + ",";
    csv += jdata.result.output.accrualduration + ",";
    //Reserved for Avg. Median Followup Time
    csv += ",";
    csv += jdata.result.output.boundary + ",";
    csv += jdata.result.output.timerequired + ",";
    csv += jdata.result.output.seed + ",";
    //Reserved for Study End Date

    csv +=
      ModuleHelpService.getFutureDate(
        jdata.accrualmgmt.firstPatientInDate,
        jdata.result.output.studyduration,
        jdata.studydesign.timeunit
      ) + ",";
    csv += jdata.result.output.studyCost + ",";
    csv += jdata.result.output.totalStudyCost + ",";
    csv += jdata.result.output.totalDiscountedStudyCost + ",";
    csv += jdata.result.output.totalSales + ",";
    csv += jdata.result.output.totalDiscountedSales + ",";
    csv += jdata.result.output.netPresentValue + ",";
    csv += jdata.result.output.probofSuccess + ",";
    csv += jdata.result.output.expNetPresentValue;

    let blob = new Blob([csv], {
      type: "application/csv;charset=" + this.encoding
    });
    saveAs(blob, jdata.result.output.scenarioid + ".csv");
  }
};

export default {
  state,
  getters,
  actions,
  mutations
};
