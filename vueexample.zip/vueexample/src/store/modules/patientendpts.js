import * as types from "@/constants/mutation-types";
import survModelsData from "@/data/survModels.js";
import SurvModelService from "../../services/survModel.service";

const state = {
  patientsEndptsData: []
};

const getters = {
  allPatientsEndptsData: state => state.patientsEndptsData
};

const actions = {
  [types.updateAllocRatio]({ commit }, payload) {
    commit(types.updateAllocRatio, payload);
  },

  [types.updateSurvModel]({ commit }, payload) {
    commit(types.updateSurvModel, payload.paramVal);
  },

  [types.updateSurvInputMethod]({ commit }, payload) {
    commit(types.updateSurvInputMethod, payload.paramVal);
  },

  [types.updateSurvModelControl]({ commit }, payload) {
    commit(types.updateSurvModelControl, payload.paramVal);
  },

  [types.updateSurvModelTreatment]({ commit }, payload) {
    commit(types.updateSurvModelTreatment, payload.paramVal);
  },

  [types.updateSurvModelHazardRatio]({ commit }, payload) {
    commit(types.updateSurvModelHazardRatio, payload.paramVal);
  },

  [types.updateDropoutRateModel]({ commit }, payload) {
    commit(types.updateDropoutRateModel, payload.paramVal);
  },

  [types.updateDropoutRateInputMethod]({ commit }, payload) {
    commit(types.updateDropoutRateInputMethod, payload.paramVal);
  },

  [types.updateDropoutRateControl]({ commit }, payload) {
    commit(types.updateDropoutRateControl, payload.paramVal);
  },

  [types.updateDropoutRateTreatment]({ commit }, payload) {
    commit(types.updateDropoutRateTreatment, payload.paramVal);
  },

  [types.updateDropoutRateByTime]({ commit }, payload) {
    commit(types.updateDropoutRateByTime, payload.paramVal);
  },

  [types.updateMaxFollowUpTimeType]({ commit }, payload) {
    commit(types.updateMaxFollowUpTimeType, payload.paramVal);
  },

  [types.updateFixedFollowUpTime]({ commit }, payload) {
    commit(types.updateFixedFollowUpTime, payload.paramVal);
  },

  async [types.fetchSurvModels]({ commit }) {
    commit(types.setSurvModels, survModelsData);
  }
};

const mutations = {
  [types.updateAllocRatio](state, payload) {
    let designIndex = SurvModelService.getDesignIndex(
      state.patientsEndptsData,
      payload.designId
    );

    if (designIndex !== -1)
      state.patientsEndptsData[designIndex].allocRatio = payload.paramVal;
  },

  [types.updateSurvModel](state, payload) {
    let designIndex = SurvModelService.getDesignIndex(
      state.patientsEndptsData,
      payload.designId
    );

    if (designIndex !== -1)
      state.patientsEndptsData[designIndex].survModel = payload.paramVal;
  },

  [types.updateSurvInputMethod](state, payload) {
    let designIndex = SurvModelService.getDesignIndex(
      state.patientsEndptsData,
      payload.designId
    );

    if (designIndex !== -1)
      state.patientsEndptsData[designIndex].survInputMethod = payload.paramVal;
  },

  [types.updateSurvModelControl](state, payload) {
    let designIndex = SurvModelService.getDesignIndex(
      state.patientsEndptsData,
      payload.designId
    );

    if (designIndex !== -1)
      state.patientsEndptsData[designIndex].survModelControl = payload.paramVal;
  },

  [types.updateSurvModelTreatment](state, payload) {
    let designIndex = SurvModelService.getDesignIndex(
      state.patientsEndptsData,
      payload.designId
    );

    if (designIndex !== -1)
      state.patientsEndptsData[designIndex].survModelTreatment =
        payload.paramVal;
  },

  [types.updateSurvModelHazardRatio](state, payload) {
    let designIndex = SurvModelService.getDesignIndex(
      state.patientsEndptsData,
      payload.designId
    );

    if (designIndex !== -1)
      state.patientsEndptsData[designIndex].survModelHazardRatio =
        payload.paramVal;
  },

  [types.updateDropoutRateModel](state, payload) {
    let designIndex = SurvModelService.getDesignIndex(
      state.patientsEndptsData,
      payload.designId
    );

    if (designIndex !== -1)
      state.patientsEndptsData[designIndex].dropoutRateModel = payload.paramVal;
  },

  [types.updateDropoutRateInputMethod](state, payload) {
    let designIndex = SurvModelService.getDesignIndex(
      state.patientsEndptsData,
      payload.designId
    );

    if (designIndex !== -1)
      state.patientsEndptsData[designIndex].dropoutRateInputMethod =
        payload.paramVal;
  },

  [types.updateDropoutRateControl](state, payload) {
    let designIndex = SurvModelService.getDesignIndex(
      state.patientsEndptsData,
      payload.designId
    );

    if (designIndex !== -1)
      state.patientsEndptsData[designIndex].dropoutRateControl =
        payload.paramVal;
  },

  [types.updateDropoutRateTreatment](state, payload) {
    let designIndex = SurvModelService.getDesignIndex(
      state.patientsEndptsData,
      payload.designId
    );

    if (designIndex !== -1)
      state.patientsEndptsData[designIndex].dropoutRateTreatment =
        payload.paramVal;
  },

  [types.updateDropoutRateByTime](state, payload) {
    let designIndex = SurvModelService.getDesignIndex(
      state.patientsEndptsData,
      payload.designId
    );

    if (designIndex !== -1)
      state.patientsEndptsData[designIndex].dropoutRateByTime =
        payload.paramVal;
  },

  [types.updateMaxFollowUpTimeType](state, payload) {
    let designIndex = SurvModelService.getDesignIndex(
      state.patientsEndptsData,
      payload.designId
    );

    if (designIndex !== -1)
      state.patientsEndptsData[designIndex].maxFollowupTimeType =
        payload.paramVal;
  },

  [types.updateFixedFollowUpTime](state, payload) {
    let designIndex = SurvModelService.getDesignIndex(
      state.patientsEndptsData,
      payload.designId
    );

    if (designIndex !== -1)
      state.patientsEndptsData[designIndex].fixedFollowUpTime =
        payload.paramVal;
  },

  [types.setSurvModels](state, payload) {
    state.patientsEndptsData = payload;
  }
};

export default {
  state,
  getters,
  actions,
  mutations
};
