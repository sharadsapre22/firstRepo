import * as types from "@/constants/action-types";
import * as mutationTypes from "@/constants/mutation-types";
import ModuleHelpService from "@/utils/moduleHelpService";

const state = {
  studyDesignData: []
};

const getters = {
  getAllStudyDesignData: state => state.studyDesignData
};

const actions = {
  [types.updateNoofIA]({ commit }, payload) {
    commit(mutationTypes.UPDATENOOFIA, payload);
  },

  [types.updatePercEventsAtIA]({ commit }, payload) {
    commit(mutationTypes.UPDATEPERCEVENTSATIA, payload);
  },

  [types.updateTimeUnit]({ commit }, payload) {
    commit(mutationTypes.UPDATETIMEUNIT, payload);
  },

  async [types.fetchStudyDesignData]({ commit }, payload) {
    commit(mutationTypes.SET_STUDYDESIGNDATA, payload);
  }
};

const mutations = {
  // Mutation to update Patient One
  [mutationTypes.UPDATENOOFIA](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.studyDesignData,
      payload.referenceId
    );

    if (index !== -1)
      state.studyDesignData[index].data.noofIA = payload.paramVal;
  },

  // Mutation to update Patient Two
  [mutationTypes.UPDATEPERCEVENTSATIA](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.studyDesignData,
      payload.referenceId
    );

    if (index !== -1)
      state.studyDesignData[index].data.percEventsAtIA = payload.paramVal;
  },

  // Mutation to update Time One
  [mutationTypes.UPDATETIMEUNIT](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.studyDesignData,
      payload.referenceId
    );
    if (index !== -1) {
      state.studyDesignData[index].data.timeUnit = payload.paramVal;
    }
  },

  // Mutation to set the data
  [mutationTypes.SET_STUDYDESIGNDATA](state, payload) {
    state.studyDesignData = payload;
  }
};
export default {
  state,
  getters,
  actions,
  mutations
};
