import * as actionTypes from "@/constants/action-types";
import * as mutationTypes from "@/constants/mutation-types";
import ModuleHelpService from "@/utils/moduleHelpService";

const state = {
  treatmentCollection: []
};

const getters = {
  // Returns read-only collection of treatment
  getAllTreatmentCollection: state => state.treatmentCollection,

  // Returns read-only treatment for a given id
  getSingleTreatmentCollection: (state, id) => {
    return ModuleHelpService.getItemAtIndex(state.treatmentCollection, id);
  }
};

const actions = {
  // Action to update Treatment
  async [actionTypes.updateTreatment]({ commit }, payload) {
    commit(mutationTypes.UPDATE_TREATMENT, payload);
  },

  // Action to update Control
  async [actionTypes.updateControl]({ commit }, payload) {
    commit(mutationTypes.UPDATE_CONTROL, payload);
  },

  // Action to fetch the data
  async [actionTypes.fetchTreatmentCollection]({ commit }, payload) {
    commit(mutationTypes.SET_TREATMENTCOLLECTION, payload);
  }
};

const mutations = {
  // Mutation to update treatment
  [mutationTypes.UPDATE_TREATMENT](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.treatmentCollection,
      payload.referenceId
    );

    if (index !== -1)
      state.treatmentCollection[index].data.treatment = payload.paramVal;
  },

  // Mutation to update control
  [mutationTypes.UPDATE_CONTROL](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.treatmentCollection,
      payload.referenceId
    );

    if (index !== -1)
      state.treatmentCollection[index].data.control = payload.paramVal;
  },

  // Mutation to set the data
  [mutationTypes.SET_TREATMENTCOLLECTION](state, payload) {
    state.treatmentCollection = payload;
  }
};

const modules = [];

export default {
  state,
  getters,
  actions,
  mutations,
  modules
};
