import * as actionTypes from "@/constants/action-types";
import * as mutationTypes from "@/constants/mutation-types";
import ModuleHelpService from "@/utils/moduleHelpService";

const state = {
  regulatoryCollection: []
};

const getters = {
  // Returns read-only collection of regulatory data
  getAllRegulatoryCollection: state => state.regulatoryCollection,

  // Returns read-only regulatory data for a given id
  getSingleRegulatoryCollection: (state, id) => {
    return ModuleHelpService.getItemAtIndex(state.regulatoryCollection, id);
  }
};

const actions = {
  // Action to update regulatory revie time
  async [actionTypes.updateRegulatoryReviewPeriod]({ commit }, payload) {
    commit(mutationTypes.UPDATE_REGULATORYREVIEWPERIOD, payload);
  },

  // Action to update prob. of approval
  async [actionTypes.updateProbOfApproval]({ commit }, payload) {
    commit(mutationTypes.UPDATE_PROBOFAPPROVAL, payload);
  },

  // Action to fetch the data
  async [actionTypes.fetchRegulatoryCollection]({ commit }, payload) {
    commit(mutationTypes.SET_REGULATORYCOLLECTION, payload);
  }
};

const mutations = {
  // Mutation to update regulatory review period
  [mutationTypes.UPDATE_REGULATORYREVIEWPERIOD](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.regulatoryCollection,
      payload.referenceId
    );

    if (index !== -1)
      state.regulatoryCollection[index].data.regulatoryreviewperiod =
        payload.paramVal;
  },

  // Mutation to update prob. of approval
  [mutationTypes.UPDATE_PROBOFAPPROVAL](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.regulatoryCollection,
      payload.referenceId
    );

    if (index !== -1)
      state.regulatoryCollection[index].data.probofApproval = payload.paramVal;
  },

  // Mutation to set the data
  [mutationTypes.SET_REGULATORYCOLLECTION](state, payload) {
    state.regulatoryCollection = payload;
  }
};

const modules = [];

export default {
  state,
  getters,
  actions,
  mutations,
  modules
};
