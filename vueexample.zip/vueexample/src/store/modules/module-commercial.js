import * as actionTypes from "@/constants/action-types";
import * as mutationTypes from "@/constants/mutation-types";
import ModuleHelpService from "@/utils/moduleHelpService";

const state = {
  commercialData: []
};

const getters = {
  // Returns read-only collection of Commercial data
  getAllCommercialData: state => state.commercialData,

  // Returns read-only Commercial data for a given id
  getSingleCommercialData: (state, id) => {
    return ModuleHelpService.getItemAtIndex(state.commercialData, id);
  }
};

const actions = {
  // Action to update Avg. Cost Per Patient
  [actionTypes.updateAvgCostPerPatient]({ commit }, payload) {
    commit(mutationTypes.UPDATE_AVGCOSTPERPATIENT, payload);
  },

  // Action to update Development Cost
  [actionTypes.updateDevelopmentCost]({ commit }, payload) {
    commit(mutationTypes.UPDATE_DEVELOPMENTCOST, payload);
  },

  // Action to update Max. Trial Cost
  [actionTypes.updateMaxTrialCost]({ commit }, payload) {
    commit(mutationTypes.UPDATE_MAXTRIALCOST, payload);
  },

  // Action to update Hazard Ratio Limit
  [actionTypes.updateHazardRatioLimit]({ commit }, payload) {
    commit(mutationTypes.UPDATE_HAZARDRATIOLIMIT, payload);
  },

  // Action to update Patent Life At Trial Start
  [actionTypes.updatePatentLifeAtTrialStart]({ commit }, payload) {
    commit(mutationTypes.UPDATE_PATENTLIFEATTRIALSTART, payload);
  },

  // Action to update Peak Net Revenue
  [actionTypes.updatePeakNetRevenue]({ commit }, payload) {
    commit(mutationTypes.UPDATE_PEAKNETREVENUE, payload);
  },

  // Action to update Discount Rate
  [actionTypes.updateDiscountRate]({ commit }, payload) {
    commit(mutationTypes.UPDATE_DISCOUNTRATE, payload);
  },

  async [actionTypes.fetchCommercialData]({ commit }, payload) {
    commit(mutationTypes.SET_COMMERCIALDATA, payload);
  }
};

const mutations = {
  // Mutation to update Avg. Cost Per Patient
  [mutationTypes.UPDATE_AVGCOSTPERPATIENT](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.commercialData,
      payload.referenceId
    );

    if (index !== -1)
      state.commercialData[index].data.avgCostPerPatient = payload.paramVal;
  },

  // Mutation to update Development Cost
  [mutationTypes.UPDATE_DEVELOPMENTCOST](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.commercialData,
      payload.referenceId
    );

    if (index !== -1)
      state.commercialData[index].data.developmentCost = payload.paramVal;
  },

  // Mutation to update Max. Trial Cost
  [mutationTypes.UPDATE_MAXTRIALCOST](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.commercialData,
      payload.referenceId
    );

    if (index !== -1)
      state.commercialData[index].data.maxTrialCost = payload.paramVal;
  },

  // Mutation to update Hazard Ratio Limit
  [mutationTypes.UPDATE_HAZARDRATIOLIMIT](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.commercialData,
      payload.referenceId
    );

    if (index !== -1)
      state.commercialData[index].data.hazardRatioLimit = payload.paramVal;
  },

  // Mutation to update Patent Life At Trial Start
  [mutationTypes.UPDATE_PATENTLIFEATTRIALSTART](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.commercialData,
      payload.referenceId
    );

    if (index !== -1)
      state.commercialData[index].data.patentLifeAtTrialStart =
        payload.paramVal;
  },

  // Mutation to update Peak Net Revenue
  [mutationTypes.UPDATE_PEAKNETREVENUE](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.commercialData,
      payload.referenceId
    );

    if (index !== -1)
      state.commercialData[index].data.peakNetRevenue = payload.paramVal;
  },

  // Mutation to update Discount Rate
  [mutationTypes.UPDATE_DISCOUNTRATE](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.commercialData,
      payload.referenceId
    );

    if (index !== -1)
      state.commercialData[index].data.discountRate = payload.paramVal;
  },

  // Mutation to set the data
  [mutationTypes.SET_COMMERCIALDATA](state, payload) {
    state.commercialData = payload;
  }
};

const modules = [];

export default {
  state,
  getters,
  actions,
  mutations,
  modules
};
