import * as types from "@/constants/mutation-types";
//import safetyRegulatoryData from "@/data/safetyRegulatory.js";
import SafetyRegulatoryService from "../../services/safetyRegulatory.service";

const state = {
  // Collection of designs received from Design Advisor Collections
  designs: []
  //safetyRegulatory: []
};

const getters = {
  allDesigns: state => state.designs,
  singleDesign: (state, id) => SafetyRegulatoryService.getDesignIndex([], id)
};

const actions = {
  [types.updatePatientOne]({ commit }, payload) {
    commit(types.updatePatientOne, payload);
  },

  [types.updatePatientTwo]({ commit }, payload) {
    commit(types.updatePatientTwo, payload);
  },

  [types.updateTimeOne]({ commit }, payload) {
    commit(types.updateTimeOne, payload);
  },

  [types.updateTimeTwo]({ commit }, payload) {
    commit(types.updateTimeTwo, payload);
  },

  async [types.fetchSafetyRegulatory]({ commit }, payload) {
    commit(types.setSafetyRegulatory, payload);
  }
};

const mutations = {
  [types.updatePatientOne](state, payload) {
    let designIndex = SafetyRegulatoryService.getDesignIndex(
      state.safetyRegulatory,
      payload.referenceId
    );

    if (designIndex !== -1)
      state.safetyRegulatory[designIndex].patientOne = payload.paramVal;
  },

  [types.updatePatientTwo](state, payload) {
    let designIndex = SafetyRegulatoryService.getDesignIndex(
      state.safetyRegulatory,
      payload.referenceId
    );

    if (designIndex !== -1)
      state.safetyRegulatory[designIndex].patientTwo = payload.paramVal;
  },

  [types.updateTimeOne](state, payload) {
    let designIndex = SafetyRegulatoryService.getDesignIndex(
      state.safetyRegulatory,
      payload.referenceId
    );

    if (designIndex !== -1)
      state.safetyRegulatory[designIndex].timeOne = payload.paramVal;
  },

  [types.updateTimeTwo](state, payload) {
    let designIndex = SafetyRegulatoryService.getDesignIndex(
      state.safetyRegulatory,
      payload.referenceId
    );

    if (designIndex !== -1)
      state.safetyRegulatory[designIndex].timeTwo = payload.paramVal;
  },

  [types.setSafetyRegulatory](state, payload) {
    state.safetyRegulatory = payload;
  }
};

export default {
  state,
  getters,
  actions,
  mutations
};
