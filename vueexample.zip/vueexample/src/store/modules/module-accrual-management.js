import * as actionTypes from "@/constants/action-types";
import * as mutationTypes from "@/constants/mutation-types";
import ModuleHelpService from "@/utils/moduleHelpService";

const state = {
  accrualManagementData: []
};

const getters = {
  // Returns read-only collection of Accrual Management data
  getAllAccrualManagementData: state => state.accrualManagementData,

  // Returns read-only Accrual Management data for a given id
  getSingleAccrualManagementData: (state, id) => {
    return ModuleHelpService.getItemAtIndex(state.accrualManagementData, id);
  }
};

const actions = {
  async [actionTypes.updateNoofPatients]({ commit }, payload) {
    commit(mutationTypes.UPDATE_NOOFPATIENTS, payload);
  },

  async [actionTypes.updateFirstPatientInDate]({ commit }, payload) {
    commit(mutationTypes.UPDATE_FIRSTPATIENTINDATE, payload);
  },

  async [actionTypes.updateAvgPatientsPerTimeUnit]({ commit }, payload) {
    commit(mutationTypes.UPDATE_AVGPATIENTSPERTIMEUNIT, payload);
  },

  async [actionTypes.updateRandomizationType]({ commit }, payload) {
    commit(mutationTypes.UPDATE_RANDOMIZATIONTYPE, payload);
  },

  async [actionTypes.fetchAccrualMgmtData]({ commit }, payload) {
    commit(mutationTypes.SET_ACCRUALMGMTDATA, payload);
  }
};

const mutations = {
  [mutationTypes.UPDATE_NOOFPATIENTS](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.accrualManagementData,
      payload.referenceId
    );

    if (index !== -1)
      state.accrualManagementData[index].data.noofPatients = payload.paramVal;
  },

  [mutationTypes.UPDATE_FIRSTPATIENTINDATE](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.accrualManagementData,
      payload.referenceId
    );

    if (index !== -1)
      state.accrualManagementData[index].data.firstPatientInDate =
        payload.paramVal;
  },

  [mutationTypes.UPDATE_AVGPATIENTSPERTIMEUNIT](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.accrualManagementData,
      payload.referenceId
    );

    if (index !== -1)
      state.accrualManagementData[index].data.avgPatientsPerTimeUnit =
        payload.paramVal;
  },

  [mutationTypes.UPDATE_RANDOMIZATIONTYPE](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.accrualManagementData,
      payload.referenceId
    );

    if (index !== -1)
      state.accrualManagementData[index].data.randomizationType =
        payload.paramVal;
  },

  // Mutation to set the data
  [mutationTypes.SET_ACCRUALMGMTDATA](state, payload) {
    state.accrualManagementData = payload;
  }
};

const modules = [];

export default {
  state,
  getters,
  actions,
  mutations,
  modules
};
