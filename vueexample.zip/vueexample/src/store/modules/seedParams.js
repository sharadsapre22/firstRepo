import * as types from "@/constants/mutation-types";
import seedParamsData from "@/data/seedparams.js";

const state = {
  seedParams: {}
};

const getters = {
  seedParams: state => state.seedParams
};

const actions = {
  [types.updateSeedType]({ commit }, payload) {
    commit(types.updateSeedType, payload);
  },

  [types.updateFixedSeed]({ commit }, payload) {
    commit(types.updateFixedSeed, payload);
  },

  async [types.fetchSeedParams]({ commit }) {
    commit(types.setSeedParams, seedParamsData);
  }
};

const mutations = {
  [types.updateSeedType](state, payload) {
    state.seedParams.seedType = payload.paramVal;
  },

  [types.updateFixedSeed](state, payload) {
    state.seedParams.fixedSeed = payload.paramVal;
  },

  async [types.fetchSeedParams]({ commit }) {
    commit(types.setSeedParams, seedParamsData);
  },

  [types.setSeedParams](state, payload) {
    state.seedParams = payload;
  }
};

export default {
  state,
  getters,
  actions,
  mutations
};
