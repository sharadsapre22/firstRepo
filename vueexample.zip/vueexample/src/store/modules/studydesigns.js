import * as types from "@/constants/mutation-types";
import studyDesignsData from "@/data/studyDesigns.js";
import StudyDesignService from "../../services/studyDesign.service";

const state = {
  studyDesigns: []
};

const getters = {
  allStudyDesigns: state => state.studyDesigns
};

const actions = {
  [types.updateDesignTest]({ commit }, payload) {
    commit(types.updateDesignTest, payload);
  },

  [types.updateNoofIA]({ commit }, payload) {
    commit(types.updateNoofIA, payload);
  },

  [types.updatePercEventsAtIA]({ commit }, payload) {
    commit(types.updatePercEventsAtIA, payload.paramVal);
  },

  [types.updateTimeUnit]({ commit }, payload) {
    commit(types.updateTimeUnit, payload.paramVal);
  },

  async [types.fetchStudyDesigns]({ commit }) {
    commit(types.setStudyDesigns, studyDesignsData);
  }
};

const mutations = {
  [types.updateDesignTest](state, payload) {
    let designIndex = StudyDesignService.getDesignIndex(
      state.studyDesigns,
      payload.designId
    );

    if (designIndex !== -1)
      state.studyDesigns[designIndex].designTest = payload.paramVal;
  },
  [types.updateNoofIA](state, payload) {
    let designIndex = StudyDesignService.getDesignIndex(
      state.studyDesigns,
      payload.designId
    );

    if (designIndex !== -1)
      state.studyDesigns[designIndex].noofIA = payload.paramVal;
  },

  [types.updatePercEventsAtIA](state, payload) {
    let designIndex = StudyDesignService.getDesignIndex(
      state.studyDesigns,
      payload.designId
    );

    if (designIndex !== -1)
      state.studyDesigns[designIndex].percEventsAtIA = payload.paramVal;
  },

  [types.updateTimeUnit](state, payload) {
    let designIndex = StudyDesignService.getDesignIndex(
      state.studyDesigns,
      payload.designId
    );

    if (designIndex !== -1)
      state.studyDesigns[designIndex].timeUnit = payload.paramVal;
  },

  [types.setStudyDesigns](state, payload) {
    state.studyDesigns = payload;
  }
};

export default {
  state,
  getters,
  actions,
  mutations
};
