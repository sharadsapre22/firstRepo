import * as actionTypes from "@/constants/action-types";
import * as mutationTypes from "@/constants/mutation-types";
import ModuleHelpService from "@/utils/moduleHelpService";

const state = {
  safetyRegulatoryData: []
};

const getters = {
  // Returns read-only collection of Safety Regulatory data
  getAllSafetyRegulatoryData: state => state.safetyRegulatoryData,

  // Returns read-only Safety Regulatory data for a given id
  getSingleSafetyRegulatoryData: (state, id) => {
    return ModuleHelpService.getItemAtIndex(state.safetyRegulatoryData, id);
  }
};

const actions = {
  // Action to update Patient One
  async [actionTypes.updatePatientOne]({ commit }, payload) {
    commit(mutationTypes.UPDATE_PATIENTONE, payload);
  },

  // Action to update Patient Two
  async [actionTypes.updatePatientTwo]({ commit }, payload) {
    commit(mutationTypes.UPDATE_PATIENTTWO, payload);
  },

  // Action to update Time One
  async [actionTypes.updateTimeOne]({ commit }, payload) {
    commit(mutationTypes.UPDATE_TIMEONE, payload);
  },

  // Action to update Time Two
  async [actionTypes.updateTimeTwo]({ commit }, payload) {
    commit(mutationTypes.UPDATE_TIMETWO, payload);
  },

  // Action to fetch the data
  async [actionTypes.fetchSafetyRegulatoryData]({ commit }, payload) {
    commit(mutationTypes.SET_SAFETYREGULATORYDATA, payload);
  }
};

const mutations = {
  // Mutation to update Patient One
  [mutationTypes.UPDATE_PATIENTONE](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.safetyRegulatoryData,
      payload.referenceId
    );

    if (index !== -1)
      state.safetyRegulatoryData[index].data.patientOne = payload.paramVal;
  },

  // Mutation to update Patient Two
  [mutationTypes.UPDATE_PATIENTTWO](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.safetyRegulatoryData,
      payload.referenceId
    );

    if (index !== -1)
      state.safetyRegulatoryData[index].data.patientTwo = payload.paramVal;
  },

  // Mutation to update Time One
  [mutationTypes.UPDATE_TIMEONE](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.safetyRegulatoryData,
      payload.referenceId
    );

    if (index !== -1)
      state.safetyRegulatoryData[index].data.timeOne = payload.paramVal;
  },

  // Mutation to update Time Two
  [mutationTypes.UPDATE_TIMETWO](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.safetyRegulatoryData,
      payload.referenceId
    );

    if (index !== -1)
      state.safetyRegulatoryData[index].data.timeTwo = payload.paramVal;
  },

  // Mutation to set the data
  [mutationTypes.SET_SAFETYREGULATORYDATA](state, payload) {
    state.safetyRegulatoryData = payload;
  }
};

const modules = [];

export default {
  state,
  getters,
  actions,
  mutations,
  modules
};
