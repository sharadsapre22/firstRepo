import * as types from "@/constants/mutation-types";
import treatmentsData from "@/data/treatments.js";
import TreatmentService from "../../services/treatment.service";

const state = {
  treatments: []
};

const getters = {
  allTreatments: state => state.treatments
};

const actions = {
  [types.updateTreatment]({ commit }, payload) {
    commit(types.updateTreatment, payload);
  },

  [types.updateControl]({ commit }, payload) {
    commit(types.updateControl, payload.paramVal);
  },

  async [types.fetchTreatments]({ commit }) {
    commit(types.setTreatments, treatmentsData);
  }
};

const mutations = {
  [types.updateTreatment](state, payload) {
    let designIndex = TreatmentService.getDesignIndex(
      state.treatments,
      payload.designId
    );

    if (designIndex !== -1)
      state.treatments[designIndex].treatment = payload.paramVal;
  },
  [types.updateControl](state, payload) {
    let designIndex = TreatmentService.getDesignIndex(
      state.treatments,
      payload.designId
    );

    if (designIndex !== -1)
      state.treatments[designIndex].control = payload.paramVal;
  },

  [types.setTreatments](state, payload) {
    state.treatments = payload;
  }
};

export default {
  state,
  getters,
  actions,
  mutations
};
