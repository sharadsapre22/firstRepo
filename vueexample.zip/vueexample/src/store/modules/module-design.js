const state = {
  designCollection: []
};

const getters = {};

const actions = {};

const mutations = {};

const modules = [];

export default {
  state,
  getters,
  actions,
  mutations,
  modules
};
