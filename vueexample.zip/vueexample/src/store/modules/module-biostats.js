import * as actionTypes from "@/constants/action-types";
import * as mutationTypes from "@/constants/mutation-types";
import ModuleHelpService from "@/utils/moduleHelpService";

const state = {
  bioStatsData: []
};

const getters = {
  // Returns read-only collection of Biostats data
  getAllBioStatsData: state => state.bioStatsData,

  // Returns read-only Biostats data for a given id
  getSingleBioStatsData: (state, id) => {
    return ModuleHelpService.getItemAtIndex(state.bioStatsData, id);
  }
};

const actions = {
  // Action to update Hypothesis
  [actionTypes.updateHypothesis]({ commit }, payload) {
    commit(mutationTypes.UPDATE_HYPOTHESIS, payload);
  },

  // Action to update Test Type
  [actionTypes.updateTestType]({ commit }, payload) {
    commit(mutationTypes.UPDATE_TESTTYPE, payload);
  },

  // Action to update Tail Type
  [actionTypes.updateTailType]({ commit }, payload) {
    commit(mutationTypes.UPDATE_TAILTYPE, payload);
  },

  // Action to update Total No of Events
  [actionTypes.updateTotalNoofEvents]({ commit }, payload) {
    commit(mutationTypes.UPDATE_TOTALNOOFEVENTS, payload);
  },

  // Action to update Type I Error
  [actionTypes.updateTypeIError]({ commit }, payload) {
    commit(mutationTypes.UPDATE_TYPEIERROR, payload);
  },

  // Action to update Test Statistic
  [actionTypes.updateTestStatistic]({ commit }, payload) {
    commit(mutationTypes.UPDATE_TESTSTATISTIC, payload);
  },

  // Action to update Efficacy Boundary Family
  [actionTypes.updateEfficacyBoundaryFamily]({ commit }, payload) {
    commit(mutationTypes.UPDATE_EFFICACYBOUNDARYFAMILY, payload);
  },

  // Action to update Efficacy Spending Function
  [actionTypes.updateEfficacySpendingFunction]({ commit }, payload) {
    commit(mutationTypes.UPDATE_EFFICACYSPENDINGFUNCTION, payload);
  },

  // Action to update Efficacy Parameter
  [actionTypes.updateEfficacyParameter]({ commit }, payload) {
    commit(mutationTypes.UPDATE_EFFICACYPARAMETER, payload);
  },

  // Action to update Efficacy Type I Error
  [actionTypes.updateEfficacyTypeIError]({ commit }, payload) {
    commit(mutationTypes.UPDATE_EFFICACYTYPEIERROR, payload);
  },

  // Action to update Futility Binding
  [actionTypes.updateFutilityBinding]({ commit }, payload) {
    commit(mutationTypes.UPDATE_FUTILITYBINDING, payload);
  },

  // Action to update Futility Boundary Family
  [actionTypes.updateFutilityBoundaryFamily]({ commit }, payload) {
    commit(mutationTypes.UPDATE_FUTILITYBOUNDARYFAMILY, payload);
  },

  // Action to update Futility Parameter
  [actionTypes.updateFutilityParameter]({ commit }, payload) {
    commit(mutationTypes.UPDATE_FUTILITYPARAMETER, payload);
  },

  // Action to update No. of Simulations
  [actionTypes.updateNoofSimulations]({ commit }, payload) {
    commit(mutationTypes.UPDATE_NOOFSIMULATIONS, payload);
  },

  // Action to update Max. No. of Events If Adapt
  [actionTypes.updateMaxNoofEventsIfAdapt]({ commit }, payload) {
    commit(mutationTypes.UPDATE_MAXNOOFEVENTSIFADAPT, payload);
  },

  // Action to update Max. Sample Size If Adapt
  [actionTypes.updateMaxSampleSizeIfAdapt]({ commit }, payload) {
    commit(mutationTypes.UPDATE_MAXSAMPLESIZEIFADAPT, payload);
  },

  // Action to update Upper Limit on Study Duration
  [actionTypes.updateUpperLimitOnStudyDuration]({ commit }, payload) {
    commit(mutationTypes.UPDATE_UPPERLIMITONSTUDYDURATION, payload);
  },

  // Action to update Target CP for Reestimating Events
  [actionTypes.updateTargetCPForReestimatingEvents]({ commit }, payload) {
    commit(mutationTypes.UPDATE_TARGETCPFORREESTIMATINGEVENTS, payload);
  },

  // Action to update Promising Zone Min CP
  [actionTypes.updatePromisingZoneMinCP]({ commit }, payload) {
    commit(mutationTypes.UPDATE_PROMISINGZONEMINCP, payload);
  },

  // Action to update Promising Zone Max CP
  [actionTypes.updatePromisingZoneMaxCP]({ commit }, payload) {
    commit(mutationTypes.UPDATE_PROMISINGZONEMAXCP, payload);
  },

  // Action to fetch the data
  async [actionTypes.fetchBioStatsData]({ commit }, payload) {
    commit(mutationTypes.SET_BIOSTATSDATA, payload);
  }
};

const mutations = {
  // Mutation to update Hypothesis
  [mutationTypes.UPDATE_HYPOTHESIS](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.hypothesis = payload.paramVal;
  },

  // Mutation to update Test Type
  [mutationTypes.UPDATE_TESTTYPE](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.testType = payload.paramVal;
  },

  // Mutation to update Tail Type
  [mutationTypes.UPDATE_TAILTYPE](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.tailType = payload.paramVal;
  },

  // Mutation to update Total No. of Events
  [mutationTypes.UPDATE_TOTALNOOFEVENTS](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.totalNoofEvents = payload.paramVal;
  },

  // Mutation to update Type I Error
  [mutationTypes.UPDATE_TYPEIERROR](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.typeIError = payload.paramVal;
  },

  // Mutation to update Test Statistic
  [mutationTypes.UPDATE_TESTSTATISTIC](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.testStatistic = payload.paramVal;
  },

  // Mutation to update Efficacy Boundary Family
  [mutationTypes.UPDATE_EFFICACYBOUNDARYFAMILY](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.efficacyBoundaryFamily = payload.paramVal;
  },

  // Mutation to update Efficacy Spending Function
  [mutationTypes.UPDATE_EFFICACYSPENDINGFUNCTION](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.efficacySpendingFunction =
        payload.paramVal;
  },

  // Mutation to update Efficacy Parameter
  [mutationTypes.UPDATE_EFFICACYPARAMETER](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.efficacyParameter = payload.paramVal;
  },

  // Mutation to update Efficacy Type I Error
  [mutationTypes.UPDATE_EFFICACYTYPEIERROR](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.efficacyTypeIError = payload.paramVal;
  },

  // Mutation to update Futility Binding
  [mutationTypes.UPDATE_FUTILITYBINDING](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.futilityBinding = payload.paramVal;
  },

  // Mutation to update Futility Boundary Family
  [mutationTypes.UPDATE_FUTILITYBOUNDARYFAMILY](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.futilityBoundaryFamily = payload.paramVal;
  },

  // Mutation to update Futility Parameter
  [mutationTypes.UPDATE_FUTILITYPARAMETER](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.futilityParameter = payload.paramVal;
  },

  // Mutation to update No. of Simulations
  [mutationTypes.UPDATE_NOOFSIMULATIONS](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.noofSimulations = payload.paramVal;
  },

  // Mutation to update Max. No. of Events If Adapt
  [mutationTypes.UPDATE_MAXNOOFEVENTSIFADAPT](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.maxNoofEventsIfAdapt = payload.paramVal;
  },

  // Mutation to update Max. Sample Size If Adapt
  [mutationTypes.UPDATE_MAXSAMPLESIZEIFADAPT](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.maxSampleSizeIfAdapt = payload.paramVal;
  },

  // Mutation to update Upper Limit on Study Duration
  [mutationTypes.UPDATE_UPPERLIMITONSTUDYDURATION](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.upperLimitOnStudyDuration =
        payload.paramVal;
  },

  // Mutation to update Target CP For Reestimating Events
  [mutationTypes.UPDATE_TARGETCPFORREESTIMATINGEVENTS](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.targetCPForReestimatingEvents =
        payload.paramVal;
  },

  // Mutation to update Promising Zone Min CP
  [mutationTypes.UPDATE_PROMISINGZONEMINCP](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.promisingZoneMinCP = payload.paramVal;
  },

  // Mutation to update Promising Zone Max CP
  [mutationTypes.UPDATE_PROMISINGZONEMAXCP](state, payload) {
    let index = ModuleHelpService.getItemIndex(
      state.bioStatsData,
      payload.referenceId
    );

    if (index !== -1)
      state.bioStatsData[index].data.promisingZoneMaxCP = payload.paramVal;
  },

  // Mutation to set the data
  async [mutationTypes.SET_BIOSTATSDATA](state, payload) {
    state.bioStatsData = payload;
  }
};

const modules = [];

export default {
  state,
  getters,
  actions,
  mutations,
  modules
};
