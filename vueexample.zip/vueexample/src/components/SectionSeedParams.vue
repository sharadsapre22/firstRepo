<template>
  <div id="sectionseedparams">
    <b-container id="sectionseedparams-container" class="pt-1 mt-1 seedBox">
      <b-card id="card-sectionseedparams" no-body class="mr-5">
        <b-card-body id="card-sectionseedparams-body">
          <b-row class="m-4">
            <b-col>
              <strong>Random Number Seed</strong>
            </b-col>
          </b-row>
          <b-row class="m-4">
            <b-col md="4">
              <label class="container">
                <strong>Clock</strong>
                <input
                  id="sectionseedparams-clock"
                  v-model="seedType"
                  type="radio"
                  checked="checked"
                  name="radio"
                  value="Clock"
                />
                <span class="checkmark"></span>
              </label>
            </b-col>

            <b-col md="6">
              <label class="container">
                <strong>Input (Fixed)</strong>
                <input
                  id="sectionseedparams-inputfixed"
                  v-model="seedType"
                  type="radio"
                  checked="checked"
                  name="radio"
                  value="Fixed"
                />
                <span class="checkmark"></span>
              </label>
            </b-col>
            <b-col md="2" />
          </b-row>
          <b-row v-show="seedType === 'Fixed'" class="m-4">
            <b-col md="3">
              <strong>Seed</strong>
            </b-col>
            <b-col md="9">
              <input
                id="sectionseedparams-inputfixed-seed"
                v-model="seed"
                type="text"
                class="form-control"
              />
            </b-col>
          </b-row>
          <b-row
            ><b-button
              id="sectionseedparams-simulate"
              href="#"
              class="btnSubmit"
              @click="onSimulate"
              >Simulate</b-button
            >
            <b-spinner
              v-show="simStarted"
              label="Spinning"
              class="ml-5 mt-1"
            ></b-spinner>
          </b-row>
        </b-card-body>
      </b-card>
    </b-container>
  </div>
</template>

<script>
import { eventBus } from "../main";
import { mapActions } from "vuex";
import ModuleHelpService from "@/utils/moduleHelpService";
import { uuid } from "vue-uuid";

export default {
  name: "RandSeed",
  data: function() {
    return {
      seedType: "Clock",
      seed: 100,
      simStarted: false
    };
  },
  methods: {
    ...mapActions(["simulateDesign", "updateSeedParams"]),

    async onSimulate() {
      this.simStarted = true;

      eventBus.$emit("onSimulate");

      if (this.$store.state.designs.designs.csvfilename === "") {
        this.simStarted = false;
        alert("Please specify input CSV file name");
        return;
      }

      // Assume BioStats + Safety & Regulatory Section is Ready
      let typeIerror = this.$store.state.biostats.bioStatsData[0].data
        .typeIError;
      let totalevents = this.$store.state.biostats.bioStatsData[0].data
        .totalNoofEvents;

      let typeIErrVals = ModuleHelpService.getMultipleValues(typeIerror);
      let totaleventsVals = ModuleHelpService.getMultipleValues(totalevents);

      // //commercial
      let avgCostPerPatient = this.$store.state.commercial.commercialData[0]
        .data.avgCostPerPatient;

      let developmentCost = this.$store.state.commercial.commercialData[0].data
        .developmentCost;

      let avgCostPerPatientNotation = ModuleHelpService.getCurrencyNosFromCurrencyNotations(
        avgCostPerPatient
      );

      let developmentCostNotation = ModuleHelpService.getCurrencyNosFromCurrencyNotations(
        developmentCost
      );

      let avgCostPerPatientVals = ModuleHelpService.getMultipleValues(
        avgCostPerPatientNotation
      );

      let developmentCostVals = ModuleHelpService.getMultipleValues(
        developmentCostNotation
      );

      let noofPatients = this.$store.state.accrualmgmt.accrualManagementData[0]
        .data.noofPatients;

      let noofPatientsVals = ModuleHelpService.getMultipleValues(noofPatients);

      let avgPatientsEnrolled = this.$store.state.accrualmgmt
        .accrualManagementData[0].data.avgPatientsPerTimeUnit;

      let avgPatientsEnrolledVals = ModuleHelpService.getMultipleValues(
        avgPatientsEnrolled
      );

      var inpArray = [
        typeIErrVals,
        totaleventsVals,
        avgCostPerPatientVals,
        developmentCostVals,
        noofPatientsVals,
        avgPatientsEnrolledVals
      ];

      var cpArray = ModuleHelpService.getAllMultipleValueCombinations(inpArray);

      let biostats = [];
      let commercial = [];
      let safetyregulatory = [];
      let accrualmgmt = [];
      let treatmentarms = [];
      let regulatory = [];
      let studydesign = [];

      for (let i = 0; i < cpArray.length; i++) {
        biostats = [
          ...biostats,
          {
            scenarioid: uuid.v1().replace(/-/g, ""),
            hypothesis: this.$store.state.biostats.bioStatsData[0].data
              .hypothesis,
            testtype: this.$store.state.biostats.bioStatsData[0].data.testType,
            tailtype: this.$store.state.biostats.bioStatsData[0].data.tailType,
            totalnoofevents: cpArray[i].split("@")[1],
            fixateachlook: "Total No. of Events",
            typeIerror: cpArray[i].split("@")[0],
            teststatistics: this.$store.state.biostats.bioStatsData[0].data
              .testStatistic,
            numsimulations: this.$store.state.biostats.bioStatsData[0].data
              .noofSimulations,
            seed: this.seedType === "Fixed" ? this.seed : 0,
            seedtype: this.seedType
          }
        ];

        safetyregulatory = [
          ...safetyregulatory,
          {
            patientOne: this.$store.state.safetyregulatory
              .safetyRegulatoryData[0].data.patientOne,
            patientTwo: this.$store.state.safetyregulatory
              .safetyRegulatoryData[0].data.patientTwo,
            timeOne: this.$store.state.safetyregulatory.safetyRegulatoryData[0]
              .data.timeOne,
            timeTwo: this.$store.state.safetyregulatory.safetyRegulatoryData[0]
              .data.timeTwo
          }
        ];

        treatmentarms = [
          ...treatmentarms,
          {
            treatment: this.$store.state.treatmentarms.treatmentCollection[0]
              .data.treatment,
            control: this.$store.state.treatmentarms.treatmentCollection[0].data
              .control
          }
        ];
        studydesign = [
          ...studydesign,
          {
            numinterimanalysis: this.$store.state.studydesign.studyDesignData[0]
              .data.noofIA,
            timeunit: this.$store.state.studydesign.studyDesignData[0].data
              .timeUnit
          }
        ];

        regulatory = [
          ...regulatory,
          {
            regulatoryReviewPeriod: this.$store.state.regulatory
              .regulatoryCollection[0].data.regulatoryreviewperiod,
            probRegulatoryApproval: this.$store.state.regulatory
              .regulatoryCollection[0].data.probofApproval
          }
        ];

        commercial = [
          ...commercial,
          {
            avgCostPerPatient: cpArray[i].split("@")[2],
            developmentCost: cpArray[i].split("@")[3],
            maxTrialCost: this.$store.state.commercial.commercialData[0].data
              .maxTrialCost,
            hazardRatioLimit: this.$store.state.commercial.commercialData[0]
              .data.hazardRatioLimit,
            patentLifeAtTrialStart: this.$store.state.commercial
              .commercialData[0].data.patentLifeAtTrialStart,
            peakNetRevenue: this.$store.state.commercial.commercialData[0].data
              .peakNetRevenue,
            discountRate: this.$store.state.commercial.commercialData[0].data
              .discountRate
          }
        ];

        accrualmgmt = [
          ...accrualmgmt,
          {
            noofPatients: cpArray[i].split("@")[4],
            avgPatientsPerTimeUnit: cpArray[i].split("@")[5],
            firstPatientInDate: this.$store.state.accrualmgmt
              .accrualManagementData[0].data.firstPatientInDate,
            randomizationType: this.$store.state.accrualmgmt
              .accrualManagementData[0].data.randomizationType
          }
        ];
      }

      var json = this.prepareCSVtoJSON(
        biostats,
        safetyregulatory,
        commercial,
        accrualmgmt,
        treatmentarms,
        regulatory,
        studydesign
      );
      for (let i = 0; i < json.length; i++) {
        await this.simulateDesign({
          json: json[i],
          biostats: biostats[i],
          safetyregulatory: safetyregulatory[i],
          commercial: commercial[i],
          accrualmgmt: accrualmgmt[i],
          treatmentarms: treatmentarms[i],
          regulatory: regulatory[i],
          studydesign: studydesign[i]
        });
      }
      eventBus.$emit("onResetInputs");
      this.simStarted = false;
    },
    prepareCSVtoJSON(
      biostats,
      safetyregulatory,
      commercial,
      accrualmgmt,
      treatmentarms,
      regulatory,
      studydesign
    ) {
      var json = [];

      for (let i = 0; i < biostats.length; i++) {
        var jsonStr = {
          studydesign: {
            numinterimanalysis: parseInt(studydesign[i].numinterimanalysis),
            timeunit: studydesign[i].timeunit
          },
          treatmentarms: {
            treatment: treatmentarms[i].treatment,
            control: treatmentarms[i].control
          },
          patients: {
            allocratio: this.$store.state.designs.designs.patients.allocratio,
            survmodel: {
              modelname: this.$store.state.designs.designs.patients.survmodel
                .modelname,
              inputmethod: this.$store.state.designs.designs.patients.survmodel
                .inputmethod,
              medictrl: parseFloat(
                this.$store.state.designs.designs.patients.survmodel.medictrl
              ),
              meditrt: parseFloat(
                this.$store.state.designs.designs.patients.survmodel.meditrt
              ),
              hazardratio: parseFloat(
                this.$store.state.designs.designs.patients.survmodel.hazardratio
              )
            },
            dropoutratemodel: {
              modelname: this.$store.state.designs.designs.patients
                .dropoutratemodel.modelname,
              inputmethod: this.$store.state.designs.designs.patients
                .dropoutratemodel.inputmethod,
              bytime: parseInt(
                this.$store.state.designs.designs.patients.dropoutratemodel
                  .bytime
              ),
              probctrl: parseFloat(
                this.$store.state.designs.designs.patients.dropoutratemodel
                  .probctrl
              ),
              probtrt: parseFloat(
                this.$store.state.designs.designs.patients.dropoutratemodel
                  .probtrt
              )
            },
            maxfollowuptime: {
              method: this.$store.state.designs.designs.patients.maxfollowuptime
                .method,
              timeinmonths:
                this.$store.state.designs.designs.patients.maxfollowuptime
                  .method === "Until End of Study"
                  ? 1
                  : parseFloat(
                      this.$store.state.designs.designs.patients.maxfollowuptime
                        .timeinmonths
                    )
            }
          },
          accrandmanagement: {
            numofpatients: parseInt(accrualmgmt[i].noofPatients),
            avgpatientsenrolled: parseFloat(
              accrualmgmt[i].avgPatientsPerTimeUnit
            ),
            randomizationtype: accrualmgmt[i].randomizationType,
            firstpatientindate: accrualmgmt[i].firstPatientInDate
          },
          biostats: {
            scenarioid: biostats[i].scenarioid,
            trialtype: biostats[i].hypothesis,
            testtype: biostats[i].testtype,
            fixateachlook: biostats[i].fixateachlook,
            totalevents: parseInt(biostats[i].totalnoofevents),
            typeIerror: parseFloat(biostats[i].typeIerror),
            teststattype: biostats[i].teststatistics,
            tailtype:
              biostats[i].tailtype === "Left-tail"
                ? "Left Tailed"
                : "Right Tailed",
            numsimulations: parseInt(biostats[i].numsimulations),
            seed:
              biostats[i].seedtype === "Clock" ? 0 : parseInt(biostats[i].seed),
            seedtype: biostats[i].seedtype
          },
          safetyregulatory: {
            patientOne: parseFloat(safetyregulatory[i].patientOne),
            patientTwo: parseFloat(safetyregulatory[i].patientTwo),
            timeOne: parseFloat(safetyregulatory[i].timeOne),
            timeTwo: parseFloat(safetyregulatory[i].timeTwo)
          },
          regulatory: {
            regulatoryReviewPeriod: parseFloat(
              regulatory[i].regulatoryReviewPeriod
            ),
            probRegulatoryApproval: parseFloat(
              regulatory[i].probRegulatoryApproval
            )
          },
          commercial: {
            avgCostPerPatient: parseFloat(
              ModuleHelpService.getCurrencyNumberFromNotation(
                commercial[i].avgCostPerPatient
              )
            ),
            developmentCost: parseFloat(
              ModuleHelpService.getCurrencyNumberFromNotation(
                commercial[i].developmentCost
              )
            ),
            maxTrialCost: parseFloat(
              ModuleHelpService.getCurrencyNumberFromNotation(
                commercial[i].maxTrialCost
              )
            ),
            hazardRatioLimit: parseFloat(commercial[i].hazardRatioLimit),
            patentLifeAtTrialStart: parseFloat(
              commercial[i].patentLifeAtTrialStart
            ),
            peakNetRevenue: parseFloat(
              ModuleHelpService.getCurrencyNumberFromNotation(
                commercial[i].peakNetRevenue
              )
            ),
            discountRatePerc: parseFloat(commercial[i].discountRate)
          }
        };
        json = [...json, jsonStr];
      }

      return json;
    }
  }
};
</script>

<style scoped>
.seedType {
  margin-bottom: 10px;
}
.seedBox {
  width: 600px;
  align-self: center;
}

#sectionseedparams-container {
  color: #006ba0;
}

.btnSubmit {
  background-color: #006ba0;
  margin-left: 50px;
}

/* The container */
.container {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 18px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default radio button */
.container input[type="radio"] {
  position: absolute;
  opacity: 0;
  cursor: pointer;
}

.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 20px;
  width: 20px;
  background-color: #eee;
  border-radius: 50%;
}
/* On mouse-over, add a grey background color */
.container:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the radio button is checked, add a blue background */
.container input:checked ~ .checkmark {
  background-color: #006ba0;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the indicator (dot/circle) when checked */
.container input:checked ~ .checkmark:after {
  display: block;
}

/* Style the indicator (dot/circle) */
.container .checkmark:after {
  top: 7px;
  left: 7px;
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: white;
}
</style>
