<template>
  <b-container id="sectionfileheader-container" class="pt-1 mt-1">
    <b-card id="card-sectionfileheader" no-body class="mr-5">
      <b-card-body id="card-sectionfileheader-body">
        <b-row class="ml-4">
          <b-col>
            <strong>Read Input File</strong>
          </b-col>
        </b-row>
        <b-row style="margin-left:10px;">
          <b-col>
            <input
              id="sectionfileheader-choosefile"
              ref="fileInput"
              type="file"
              class="form-control"
              style="color:#006ba0;border: 0px; margin-top:5px;margin-bottom:5px;"
              @change="loadDataFromFile"
            />
          </b-col>
        </b-row>
      </b-card-body>
    </b-card>
  </b-container>
</template>

<script>
import { eventBus } from "../main";
import { mapActions } from "vuex";

export default {
  data() {
    return {
      filereader: {
        csvfilename: "",
        csvdata: []
      }
    };
  },
  mounted() {
    eventBus.$on("onSimulate", () => {
      this.updateDesign({
        csvfilename: this.filereader.csvfilename,
        csvdata: this.filereader.csvdata
      });
    });
    eventBus.$on("onResetInputs", () => {
      this.$refs.fileInput.value = "";
      this.filereader.csvfilename = "";
      this.csvdata = "";
      this.updateDesign({ csvfilename: "", csvdata: "" });
    });
  },
  methods: {
    ...mapActions(["updateDesign"]),

    loadDataFromFile(ev) {
      const file = ev.target.files[0];
      this.filereader.csvfilename = file.name;
      const reader = new FileReader();

      reader.onload = e => {
        this.filereader.csvdata = e.target.result.split("\r\n");
      };
      reader.readAsText(file);
    }
  }
};
</script>

<style>
#sectionbiostats-container {
  color: #006ba0;
}

.text-reader {
  position: relative;
  overflow: hidden;
  display: inline-block;

  /* Fancy button looking */
  border: 0px solid black;
  border-radius: 5px;
  padding: 8px 12px;
  cursor: pointer;
}
.text-reader input {
  position: absolute;
  top: 0;
  left: 0;
  z-index: -1;
  opacity: 0;
}
</style>
