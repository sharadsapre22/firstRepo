<template>
  <div id="pagefooter">
    <b-navbar
      id="pagefooter-navbar"
      toggleable="lg"
      type="dark"
      fixed="bottom"
      class="pagefooter"
    >
      <b-navbar-toggle
        id="pgfooter-nbar-toggle"
        target="pgfooter-nbar-collapse"
      ></b-navbar-toggle>
      <b-collapse id="pgfooter-nbar-collapse" is-nav>
        <b-navbar-nav
          id="pgfooter-nbar-collapse-nav"
          active
          class="ml-auto mr-auto"
        >
          <b-nav-item
            id="pgfooter-nbar-collapse-nav-designadvisor"
            class="ml-5 mr-5"
            :active="$route.path == '/designadvisor'"
            to="/designadvisor"
          >
            <span id="pgfooter-nbar-collapse-nav-designadvisor-span">
              <strong id="pgfooter-nbar-collapse-nav-designadvisor-title"
                >Design Advisor</strong
              >
            </span>
          </b-nav-item>
          <b-nav-item
            id="pgfooter-nbar-collapse-nav-inputadvisor"
            class="ml-5 mr-5"
            :active="$route.path == '/inputadvisor'"
            to="/inputadvisor"
          >
            <span id="pgfooter-nbar-collapse-nav-inputadvisor-span">
              <strong id="pgfooter-nbar-collapse-nav-inputadvisor-title"
                >Input Advisor</strong
              >
            </span>
          </b-nav-item>
          <b-nav-item
            id="pgfooter-nbar-collapse-nav-simulation"
            class="ml-5 mr-5"
            :active="$route.path == '/simulation'"
            to="/simulation"
          >
            <span id="pgfooter-nbar-collapse-nav-simulation-span">
              <strong id="pgfooter-nbar-collapse-nav-simulation-title"
                >Simulation</strong
              >
            </span>
          </b-nav-item>
          <b-nav-item
            id="pgfooter-nbar-collapse-nav-tradeoffadvisor"
            class="ml-5 mr-5"
            :active="$route.path == '/tradeoffadvisor'"
            to="/tradeoffadvisor"
          >
            <span id="pgfooter-nbar-collapse-nav-tradeoffadvisor-span">
              <strong id="pagefooter-navbar-collapse-nav-tradeoffadvisor-title"
                >Tradeoff Advisor</strong
              >
            </span>
          </b-nav-item>
        </b-navbar-nav>
      </b-collapse>
    </b-navbar>
  </div>
</template>

<style scoped>
.pagefooter {
  background-color: #006ba0;
  max-height: 100%;
}
.navbar-nav .nav-link.active {
  border-bottom: 2px solid white;
}
</style>
