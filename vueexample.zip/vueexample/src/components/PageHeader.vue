<template>
  <div id="pgheader">
    <b-navbar
      id="pgheader-nbar"
      toggleable="md"
      fixed="top"
      type="dark"
      class="pageheader"
    >
      <b-navbar-brand
        id="pgheader-nbar-brnd"
        to="/designadvisor"
        class="ml-md-5"
      >
        <img
          id="pgheader-nbar-brnd-img"
          src="@/assets/logo.png"
          class="img-fluid"
          alt="Cytel"
        />
      </b-navbar-brand>
    </b-navbar>
  </div>
</template>

<style scoped>
.pageheader {
  background-color: #006ba0;
  max-height: 100%;
}
</style>
