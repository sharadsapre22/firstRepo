<template>
  <b-form-select
    :id="id"
    :reference-id="referenceId"
    :options="options"
    :disabled="disabled"
    :hidden="hidden"
    :value="value"
    @change.native="onChange"
  >
  </b-form-select>
</template>

<script>
//    @change="$emit('change', $event.target.value)"
export default {
  name: "BaseComboBox",
  props: {
    options: { type: Array, default: () => [] },
    disabled: { type: Boolean, default: false },
    hidden: { type: Boolean, default: false },
    id: { type: String, default: "" },
    referenceId: { type: String, default: "" },
    value: { type: String, default: "" }
  },
  methods: {
    onChange() {
      this.$emit("change", event.target.value, this.referenceId);
    }
  }
};
</script>

<style></style>
