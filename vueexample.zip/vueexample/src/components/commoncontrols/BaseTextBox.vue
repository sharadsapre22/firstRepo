<template>
  <b-form-input
    :id="id"
    :reference-id="referenceId"
    :placeholder="placeholder"
    :disabled="disabled"
    :hidden="hidden"
    :value="value"
    :type="type"
    @input="onInput"
    @blur="onBlur"
  />
</template>

<script>
export default {
  name: "BaseTextBox",
  props: {
    placeholder: { type: String, default: "" },
    disabled: { type: Boolean, default: false },
    hidden: { type: Boolean, default: false },
    id: { type: String, default: "" },
    referenceId: { type: String, default: "" },
    value: { type: String, default: "" },
    type: { type: String, default: "text" }
  },
  methods: {
    onInput() {
      this.$emit("input", event.target.value, this.referenceId);
    },
    onBlur() {
      this.$emit("blur", event.target.value, this.referenceId);
    }
  }
};
</script>

<style></style>
