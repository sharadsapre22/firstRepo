<template>
  <div id="recommendations">
    <b-container id="recommendations-container" class="pt-5 mt-5">
      <h4 id="recommendations-title">Recommendations</h4>
      <b-card id="recommendations-card">
        <p
          v-for="(item, index) in recommendations"
          :key="index"
          style="margin-top:0px; margin-bottom:0px;"
        >
          <strong>{{ index + 1 }} . </strong> {{ item.name }}
        </p>
        <b-card-footer id="recommendations-footer" class="text-center">
          <button
            :id="buttonNextId"
            type="button"
            class="btn btn-primary btn-sm"
            :disabled="true"
            @click="selectedDesigns"
          >
            Next
          </button>
        </b-card-footer>
      </b-card>
    </b-container>
  </div>
</template>

<script>
const root_id = "recommendations";
import { eventBus } from "../main";
import { mapActions } from "vuex";
// v-for="{ text, value } in recommendations" :key="value" :value="value" {{ text }}
export default {
  name: "Recommendations",
  data: function() {
    return {
      options: [
        { text: "2-Arm Logrank Fixed", value: "2-arm-logrank-fixed" },
        { text: "2-Arm Logrank Group Sequential", value: "2-arm-logrank-gs" },
        {
          text: "2-Arm Logrank Group Sequential with Sample Size Reestimation",
          value: "2-arm-logrank-gs-ssr"
        }
      ],
      recommendations: [],
      selected: []
    };
  },
  computed: {
    buttonNextId() {
      return root_id + "-next";
    }
  },
  mounted() {
    // listening to eventBus
    eventBus.$on("onRecommendations", recommendations => {
      //this.recommendations = this.listDesignNames(JSON.parse(recommendations));
      this.recommendations = JSON.parse(recommendations);
    });
  },
  methods: {
    ...mapActions(["selectedDesigns"]),
    listDesignNames(array) {
      let str = "";
      array.forEach(design => {
        str += design.name;
        str += ",";
      });
      return str;
    },
    deepCopy(arr) {
      JSON.parse(JSON.stringify(arr));
    }
  }
};
</script>
