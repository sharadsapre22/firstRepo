<template>
  <b-row :id="generateId(id, 'r0')" class="data">
    <b-col :id="generateId(id, 'r0c0')" class="col-3">
      Number of Patients
    </b-col>
    <!-- TODO (PK): Implementation of v-Model is pending -->
    <b-col
      v-for="(item, index) in accrualManagementData"
      :id="generateId(id, 'r0c' + (index + 1))"
      :key="index"
    >
      <BaseTextBox
        :id="generateId(id, 'r0c' + (index + 1) + '-noofpatients')"
        :reference-id="item.designId"
        :value="item.data.noofPatients"
        @blur="onUpdateNoofPatients"
        @input="onUpdateNoofPatients"
      />
    </b-col>
  </b-row>
</template>

<script>
import { mapActions } from "vuex";
import * as actionTypes from "@/constants/action-types";
import BaseTextBox from "@/components/commoncontrols/BaseTextBox.vue";

export default {
  name: "SectionNoofPatients",
  components: {
    BaseTextBox
  },
  props: {
    accrualManagementData: { type: Array, default: () => [] },
    id: { type: String, default: "" }
  },
  methods: {
    ...mapActions([actionTypes.updateNoofPatients]),

    onUpdateNoofPatients(value, referenceId) {
      this.updateNoofPatients({ paramVal: value, referenceId: referenceId });
    },

    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
