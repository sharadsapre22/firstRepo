<template>
  <b-row :id="generateId(id, 'r0')" class="data">
    <b-col :id="generateId(id, 'r0c0')" class="col-3">
      First Patient in Date
    </b-col>
    <b-col
      v-for="(item, index) in accrualManagementData"
      :id="generateId(id, 'r0c' + (index + 1))"
      :key="index"
    >
      <BaseTextBox
        :id="generateId(id, 'r0c' + (index + 1) + '-firstpatientindate')"
        :reference-id="item.designId"
        :type="'date'"
        :value="item.data.firstPatientInDate"
        @blur="onUpdateFirstPatientInDate"
        @input="onUpdateFirstPatientInDate"
      />
    </b-col>
  </b-row>
</template>

<script>
import { mapActions } from "vuex";
import * as actionTypes from "@/constants/action-types";
import BaseTextBox from "@/components/commoncontrols/BaseTextBox.vue";

export default {
  name: "SectionFirstPatientInDate",
  components: {
    BaseTextBox
  },
  props: {
    accrualManagementData: { type: Array, default: () => [] },
    id: { type: String, default: "" }
  },
  methods: {
    ...mapActions([actionTypes.updateFirstPatientInDate]),

    onUpdateFirstPatientInDate(value, referenceId) {
      this.updateFirstPatientInDate({
        paramVal: value,
        referenceId: referenceId
      });
    },

    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
