<template>
  <div :id="generateId(id, '')" class="ia-section">
    <SectionBanner
      :id="generateId(id, 'subsec-banner')"
      banner-name=" Accrual &amp; Management"
    />
    <SectionNoofPatients
      :id="generateId(id, 'subsec-noofpatients')"
      :accrual-management-data="getAllAccrualManagementData"
    />
    <SectionFirstPatientInDate
      :id="generateId(id, 'subsec-firstpatientindate')"
      :accrual-management-data="getAllAccrualManagementData"
    />
    <SectionAvgPatientsEnrolledPerTimeUnit
      :id="generateId(id, 'subsec-avgpatsenrolledpertimeunit')"
      :accrual-management-data="getAllAccrualManagementData"
    />
    <SectionRandomizationType
      :id="generateId(id, 'subsec-randomizationtype')"
      :accrual-management-data="getAllAccrualManagementData"
    />
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import SectionBanner from "@/components/finalcomponents/SectionBanner.vue";
import SectionNoofPatients from "@/components/SectionNoofPatients.vue";
import SectionAvgPatientsEnrolledPerTimeUnit from "@/components/SectionAvgPatientsEnrolledPerTimeUnit.vue";
import SectionRandomizationType from "@/components/SectionRandomizationType.vue";
import SectionFirstPatientInDate from "@/components/SectionFirstPatientInDate.vue";

export default {
  name: "SectionAccrualMgmt",
  components: {
    SectionBanner,
    SectionNoofPatients,
    SectionAvgPatientsEnrolledPerTimeUnit,
    SectionRandomizationType,
    SectionFirstPatientInDate
  },
  props: {
    id: { type: String, default: "" },
    accrualManagementData: { type: Array, default: () => [] }
  },
  computed: {
    ...mapGetters(["getAllAccrualManagementData"])
  },
  methods: {
    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
