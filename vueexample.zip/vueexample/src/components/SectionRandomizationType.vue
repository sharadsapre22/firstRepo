<template>
  <b-row :id="generateId(id, 'r0')" class="data">
    <b-col :id="generateId(id, 'r0c0')" class="col-3">
      Randomization Type
    </b-col>
    <b-col
      v-for="(item, index) in accrualManagementData"
      :id="generateId(id, 'r0c' + (index + 1))"
      :key="index"
    >
      <BaseComboBox
        :id="generateId(id, 'r0c' + (index + 1) + '-randomizationtype')"
        :reference-id="item.designId"
        :options="options"
        :value="item.data.randomizationType"
        :disabled="true"
        @change="onUpdateRandomizationType"
      />
    </b-col>
  </b-row>
</template>

<script>
import { mapActions } from "vuex";
import * as actionTypes from "@/constants/action-types";
import BaseComboBox from "@/components/commoncontrols/BaseComboBox.vue";

export default {
  name: "SectionRandomizationType",
  components: {
    BaseComboBox
  },
  props: {
    accrualManagementData: { type: Array, default: () => [] },
    id: { type: String, default: "" }
  },
  data() {
    return {
      options: [{ value: "Pure", text: "Pure" }]
    };
  },
  methods: {
    ...mapActions([actionTypes.updateRandomizationType]),

    onUpdateRandomizationType(value, referenceId) {
      this.updateRandomizationType({
        paramVal: value,
        referenceId: referenceId
      });
    },

    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style scoped></style>
