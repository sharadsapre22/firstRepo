<template>
  <div>
    <b-container class="pt-5 mt-5">
      <h4>Strategic Goals</h4>
      <b-card>
        <b-row>
          <b-col class="text-center">
            <button
              id="designadvisor-goals-maxnpv"
              type="button"
              class="btn btn-light text-center"
              @click="pushSelect('maxnpv')"
            >
              Maximize NPV
            </button>
          </b-col>
          <b-col class="text-center">
            <button
              id="designadvisor-goals-maxpos"
              type="button"
              class="btn btn-light"
              @click="pushSelect('maxpos')"
            >
              Maximize Probability of Success
            </button>
          </b-col>
        </b-row>
        <b-row>
          <b-col class="text-center">
            <button
              id="designadvisor-goals-mincost"
              type="button"
              class="btn btn-light"
              @click="pushSelect('mincost')"
            >
              Minimize Study Cost
            </button>
          </b-col>
          <b-col class="text-center">
            <button
              id="designadvisor-goals-mintime"
              type="button"
              class="btn btn-light"
              @click="pushSelect('mintime')"
            >
              Minimize Time to Completion
            </button>
          </b-col>
        </b-row>
        <div class="text-center">
          <button
            :id="buttonNextId"
            type="button"
            class="btn btn-primary btn-sm"
            :disabled="true"
            @click="scrollNext"
          >
            Next
          </button>
        </div>
      </b-card>
    </b-container>
  </div>
</template>

<script>
import { mapActions } from "vuex";
const root_id = "designadvisor-goals";
const next_card_id = "designadvisor-purpose";
export default {
  name: "StrategicGoals",
  data: function() {
    return {
      selected: new Set(),
      goals: ["maxnpv", "maxpos", "mincost", "mintime"]
    };
  },
  computed: {
    buttonNextId() {
      return root_id + "-next";
    }
  },
  methods: {
    ...mapActions(["selectGoals"]),
    pushSelect(val) {
      const elem = document.getElementById(root_id + "-" + val);
      if (!this.selected.has(val)) {
        elem.className = elem.className.replace("btn-light", "btn-info");
        this.selected.add(val);
      } else {
        elem.className = elem.className.replace("btn-info", "btn-light");
        this.selected.delete(val);
      }
      const next = document.getElementById(this.buttonNextId);
      next.disabled = this.selected.size == 0;
    },
    scrollNext() {
      this.selectGoals(this.selected);
      const elem = document.getElementById(next_card_id);
      if (elem !== null || typeof elem !== "undefined") {
        elem.scrollIntoView();
      }
    }
  }
};
</script>
