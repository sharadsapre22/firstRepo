<template>
  <div>
    <b-container id="designadvisor-groups" class="pt-5 mt-5">
      <h4 id="designadvisor-groups-title">Number of Groups</h4>
      <b-card id="designadvisor-groups-card">
        <b-row>
          <b-col class="text-center">
            <button
              id="designadvisor-groups-1"
              type="button"
              class="btn btn-light"
              @click="pushRadio('1')"
            >
              1
            </button>
          </b-col>
          <b-col class="text-center">
            <button
              id="designadvisor-groups-2"
              type="button"
              class="btn btn-light"
              @click="pushRadio('2')"
            >
              2
            </button>
          </b-col>
          <b-col class="text-center">
            <button
              id="designadvisor-groups-3+"
              type="button"
              class="btn btn-light"
              @click="pushRadio('3+')"
            >
              3+
            </button>
          </b-col>
        </b-row>
        <b-card-footer id="designadvisor-groups-footer" class="text-center">
          <button
            :id="buttonNextId"
            type="button"
            class="btn btn-primary btn-sm"
            :disabled="selected === ''"
            @click="scrollNext"
          >
            Next
          </button>
        </b-card-footer>
      </b-card>
    </b-container>
  </div>
</template>

<script>
const root_id = "designadvisor-groups";
const next_card_id = "designadvisor-recommendations";

export default {
  name: "Groups",
  data: function() {
    return {
      selected: "",
      groups: ["1", "2", "3+"]
    };
  },
  computed: {
    buttonNextId() {
      return root_id + "-next";
    },
    buttonId(val) {
      return root_id + "-" + val;
    }
  },
  methods: {
    // None or exactly one button selected
    pushRadio(val) {
      if (this.selected == val) {
        this.selected = "";
        const elem = document.getElementById(root_id + "-" + val);
        elem.className = elem.className.replace("btn-info", "btn-light");
        document.getElementById(this.buttonNextId);
      } else {
        this.selected = val;
        this.groups.forEach(x => {
          const elem = document.getElementById(root_id + "-" + x);
          elem.className =
            x == val
              ? elem.className.replace("btn-light", "btn-info")
              : elem.className.replace("btn-info", "btn-light");
        });
      }
    },
    scrollNext() {
      const elem = document.getElementById(next_card_id);
      elem.scrollIntoView();
    }
  }
};
</script>
