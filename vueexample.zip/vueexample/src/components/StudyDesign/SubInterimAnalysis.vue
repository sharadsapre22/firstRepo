<template>
  <b-row :id="generateId(id, 'r0')" class="data">
    <b-col :id="generateId(id, 'r0c0')" class="col-3">
      Number of Interim Analyses
    </b-col>
    <b-col
      v-for="(item, index) in studyDesignData"
      :id="generateId(id, 'r0c' + (index + 1))"
      :key="index"
    >
      <BaseTextBox
        :id="generateId(id, 'r0c' + (index + 1) + '-noofia')"
        :reference-id="item.designId"
        :value="item.data.noofIA"
        :disabled="true"
        @blur="onUpdateNoofIA"
        @input="onUpdateNoofIA"
      />
    </b-col>
  </b-row>
</template>

<script>
import BaseTextBox from "@/components/commoncontrols/BaseTextBox.vue";

import { mapActions } from "vuex";
import * as actionTypes from "@/constants/action-types";

export default {
  name: "InterimAnalysis",
  components: {
    BaseTextBox
  },
  props: {
    id: { type: String, default: "" },
    studyDesignData: { type: Array, default: () => [] }
  },
  methods: {
    ...mapActions([actionTypes.updateNoofIA]),

    onUpdateNoofIA(value, referenceId) {
      this.updateNoofIA({ paramVal: value, referenceId: referenceId });
    },

    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
