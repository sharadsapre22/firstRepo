<template>
  <b-row :id="generateId(id, 'r0')" class="data">
    <b-col :id="generateId(id, 'r0c0')" class="col-3">
      Time Unit
    </b-col>
    <b-col
      v-for="(item, index) in studyDesignData"
      :id="generateId(id, 'r0c' + (index + 1))"
      :key="index"
    >
      <BaseComboBox
        :id="generateId(id, 'r0c' + (index + 1) + '-timeunit')"
        :reference-id="item.designId"
        :options="options"
        :value="item.data.timeUnit"
        @change="onUpdateTimeUnit"
      />
    </b-col>
  </b-row>
</template>

<script>
import BaseComboBox from "@/components/commoncontrols/BaseComboBox.vue";
import { mapActions } from "vuex";
import * as actionTypes from "@/constants/action-types";

export default {
  name: "TimeUnit",
  components: {
    BaseComboBox
  },
  props: {
    id: { type: String, default: "" },
    studyDesignData: { type: Array, default: () => [] }
  },
  data() {
    return {
      options: [
        { value: "Days", text: "Days" },
        { value: "Weeks", text: "Weeks" },
        { value: "Months", text: "Months" },
        { value: "Years", text: "Years" }
      ],
      selectedValue: "Months"
    };
  },
  methods: {
    ...mapActions([actionTypes.updateTimeUnit]),

    onUpdateTimeUnit(value, referenceId) {
      this.updateTimeUnit({ paramVal: value, referenceId: referenceId });
    },

    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
