<template>
  <div :id="generateId(id, '')" class="ia-section">
    <SectionBanner
      :id="generateId(id, 'subsec-banner')"
      banner-name="Study Design"
    />
    <InterimAnalysis
      :id="generateId(id, 'subsec-interim')"
      :study-design-data="getAllStudyDesignData"
    />

    <TimeUnit
      :id="generateId(id, 'subsec-timeunit')"
      :study-design-data="getAllStudyDesignData"
    ></TimeUnit>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import TimeUnit from "@/components/StudyDesign/SubTimeUnit.vue";
import InterimAnalysis from "@/components/StudyDesign/SubInterimAnalysis.vue";
import SectionBanner from "@/components/finalcomponents/SectionBanner.vue";

export default {
  name: "StudyDesign",
  components: {
    TimeUnit,
    InterimAnalysis,
    SectionBanner
  },
  props: {
    studyDesignData: { type: Array, default: () => [] },
    id: { type: String, default: "" }
  },
  computed: {
    ...mapGetters(["getAllStudyDesignData"])
  },
  methods: {
    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
