<template>
  <div id="sectionbiostats">
    <b-container id="sectionbiostats-container" class="pt-5 mt-5">
      <!-- Test Title -->
      <h4 id="test-title">2-arm Logrank Fixed</h4>
      <!-- Separation Line -->
      <hr class="mr-5" />
      <!-- Biostats Section -->
      <b-card id="card-sectionbiostats" no-body class="mr-5">
        <b-card-header id="card-sectionbiostats-header">
          <h4
            id="card-sectionbiostats-header-title"
            v-b-toggle.card-sectionbiostats-collapse
            class="mb-0"
            style="cursor:pointer;"
          >
            <font-awesome-icon
              id="card-sectionbiostats-header-downicon"
              icon="chevron-down"
              class="when-opened pr-1"
            />
            <font-awesome-icon
              id="card-sectionbiostats-header-upicon"
              icon="chevron-right"
              class="when-closed pr-1"
            />
            Biostats
          </h4>
        </b-card-header>
        <b-collapse id="card-sectionbiostats-collapse" visible>
          <b-card-body id="card-sectionbiostats-body">
            <b-row class="m-4">
              <b-col md="3">
                <strong>Hypothesis</strong>
              </b-col>
              <b-col md="9">
                <input
                  id="sectionbiostats-hypothesis"
                  v-model="biostats.hypothesis"
                  type="text"
                  class="form-control"
                  disabled
                />
              </b-col>
            </b-row>
            <b-row class="m-4">
              <b-col md="3">
                <strong>Test Type</strong>
              </b-col>
              <b-col md="9">
                <input
                  id="sectionbiostats-test-type"
                  v-model="biostats.testtype"
                  type="text"
                  class="form-control"
                  disabled
                />
              </b-col>
            </b-row>
            <b-row class="m-4">
              <b-col md="3">
                <strong>Tail Type</strong>
              </b-col>
              <b-col md="9">
                <select
                  id="sectionbiostats-tail-type"
                  v-model="biostats.tailtype"
                  class="form-control"
                >
                  <option>Left-tail</option>
                  <option>Right-tail</option>
                </select>
              </b-col>
            </b-row>
            <b-row class="m-4">
              <b-col md="3">
                <strong>Total No. of Events</strong>
              </b-col>
              <b-col md="9">
                <input
                  id="sectionbiostats-total-no-of-events"
                  v-model="biostats.totalnoofevents"
                  type="text"
                  class="form-control"
                />
              </b-col>
            </b-row>
            <b-row class="m-4">
              <b-col md="3">
                <strong>Type 1 Error (Alpha)</strong>
              </b-col>
              <b-col md="9">
                <input
                  id="sectionbiostats-typeI-error-alpha"
                  v-model="biostats.typeIerror"
                  type="text"
                  class="form-control"
                />
              </b-col>
            </b-row>
            <b-row class="m-4">
              <b-col md="3">
                <strong>Test Statistic</strong>
              </b-col>
              <b-col md="9">
                <input
                  id="sectionbiostats-test-statistics"
                  v-model="biostats.teststatistics"
                  type="text"
                  class="form-control"
                  disabled
                />
              </b-col>
            </b-row>
            <b-row class="m-4">
              <b-col md="3">
                <strong>Number of Simulations</strong>
              </b-col>
              <b-col md="9">
                <input
                  id="sectionbiostats-number-of-simulations"
                  v-model="biostats.numsimulations"
                  type="text"
                  class="form-control"
                />
              </b-col>
            </b-row>
          </b-card-body>
        </b-collapse>
      </b-card>
    </b-container>
  </div>
</template>

<script>
import { eventBus } from "../main";
import { mapActions } from "vuex";
import { uuid } from "vue-uuid";

export default {
  name: "SectionBiostats",
  data() {
    return {
      biostats: {
        scenarioid: "",
        hypothesis: "Superiority",
        fixateachlook: "Total No. of Events",
        testtype: "1-sided",
        tailtype: "Left-tail",
        totalnoofevents: "350",
        typeIerror: "0.05",
        teststatistics: "Logrank",
        numsimulations: "10000"
      }
    };
  },
  mounted() {
    // listening to eventBus
    eventBus.$on("onSimulate", () => {
      let typeIerror = this.biostats.typeIerror;
      let totalevents = this.biostats.totalnoofevents;

      let typeIErrVals = this.splitvalues(typeIerror);
      let totaleventsVals = this.splitvalues(totalevents);

      var inpArray = [typeIErrVals, totaleventsVals];
      var cpArray = this.cyCartesianProduct(inpArray);

      let biostats = [];
      for (let i = 0; i < cpArray.length; i++) {
        biostats = [
          ...biostats,
          {
            scenarioid: uuid.v1().replace(/-/g, ""),
            hypothesis: this.biostats.hypothesis,
            testtype: this.biostats.testtype,
            tailtype: this.biostats.tailtype,
            totalnoofevents: cpArray[i].split(":")[1],
            fixateachlook: this.biostats.fixateachlook,
            typeIerror: cpArray[i].split(":")[0],
            teststatistics: this.biostats.teststatistics,
            numsimulations: this.biostats.numsimulations,
            seed: "",
            seedtype: ""
          }
        ];
      }
      this.updateBioStats(biostats);
    });
  },
  methods: {
    ...mapActions(["updateBioStats"]),
    cyFindRangeValues(start, end, step = 1) {
      if (isNaN(start) || isNaN(end) || isNaN(step)) return;

      var diff = Math.round((end - start) * 1000000) / 1000000;
      const intervals = Math.ceil(diff / (step == 0 ? 1 : step));
      const len = intervals == 0 ? 1 : intervals + 1;
      var arr = Array(len)
        .fill()
        .map((_, idx) =>
          Math.round((start + idx * step) * 1000000) / 1000000 > end
            ? end
            : Math.round((start + idx * step) * 1000000) / 1000000
        );
      return arr.filter((v, i, a) => a.indexOf(v) === i);
    },

    cyCartesianProduct(arrays) {
      let result = arrays.reduce((a, b) =>
        a.reduce((r, v) => r.concat(b.map(w => [].concat(v, w))), [])
      );
      return result.map(a => a.join(":"));
    },
    splitvalues(range) {
      let rangeSpecified = range.includes(":");
      let commaSpecified = range.includes(",");

      if (rangeSpecified == false && commaSpecified == false) return [range];

      let splitArr = range.split(",");
      let myVals = [];

      for (let i = 0; i < splitArr.length; i++) {
        let rangeSpecified = splitArr[i].includes(":");

        if (rangeSpecified && splitArr[i].split(":").length == 3) {
          let start = parseFloat(splitArr[i].split(":")[0]);
          let end = parseFloat(splitArr[i].split(":")[1]);
          let step = parseFloat(splitArr[i].split(":")[2]);
          myVals = [...myVals, ...this.cyFindRangeValues(start, end, step)];
        } else {
          myVals = [...myVals, parseFloat(splitArr[i])];
        }
      }

      return myVals;
    }
  }
};
</script>

<style scoped>
#card-sectionbiostats-header {
  text-align: left;
  background-color: transparent;
  border: none;
}

#sectionbiostats-container {
  color: #006ba0;
}

.list-group-flush .list-group-item {
  border: 0px;
}

hr {
  border-bottom: 1px solid #006ba0;
  margin-right: 10px;
}

.collapsed > .when-opened,
:not(.collapsed) > .when-closed {
  display: none;
}
</style>
