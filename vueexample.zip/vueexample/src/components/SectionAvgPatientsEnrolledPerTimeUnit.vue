<template>
  <b-row :id="generateId(id, 'r0')" class="data">
    <b-col :id="generateId(id, 'r0c0')" class="col-3">
      Average Patients Enrolled per Time Unit
    </b-col>
    <b-col
      v-for="(item, index) in accrualManagementData"
      :id="generateId(id, 'r0c' + (index + 1))"
      :key="index"
    >
      <BaseTextBox
        :id="
          generateId(id, 'r0c' + (index + 1) + '-avgpatsenrolledpertimeunit')
        "
        :reference-id="item.designId"
        :value="item.data.avgPatientsPerTimeUnit"
        @blur="onUpdateAvgPatientsPerTimeUnit"
        @input="onUpdateAvgPatientsPerTimeUnit"
      />
    </b-col>
  </b-row>
</template>

<script>
import { mapActions } from "vuex";
import * as actionTypes from "@/constants/action-types";
import BaseTextBox from "@/components/commoncontrols/BaseTextBox.vue";
export default {
  name: "SectionAvgPatientsEnrolledPerTimeUnit",
  components: {
    BaseTextBox
  },
  props: {
    accrualManagementData: { type: Array, default: () => [] },
    id: { type: String, default: "" }
  },
  methods: {
    ...mapActions([actionTypes.updateAvgPatientsPerTimeUnit]),

    onUpdateAvgPatientsPerTimeUnit(value, referenceId) {
      this.updateAvgPatientsPerTimeUnit({
        paramVal: value,
        referenceId: referenceId
      });
    },

    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
