<template>
  <div :id="generateId(id, '')" class="ia-section">
    <SectionBanner
      :id="generateId(id, 'subsec-banner')"
      banner-name="Biostats"
    />
    <SectionHypothesis
      :id="generateId(id, 'subsec-hypothesis')"
      :bio-stats-data="getAllBioStatsData"
    />
    <SectionTestType
      :id="generateId(id, 'subsec-testtype')"
      :bio-stats-data="getAllBioStatsData"
    />
    <SectionTailType
      :id="generateId(id, 'subsec-tailtype')"
      :bio-stats-data="getAllBioStatsData"
    />
    <SectionTotalNoofEvents
      :id="generateId(id, 'subsec-totalnoofevents')"
      :bio-stats-data="getAllBioStatsData"
    />
    <SectionTypeIError
      :id="generateId(id, 'subsec-typeIerror')"
      :bio-stats-data="getAllBioStatsData"
    />
    <SectionTestStatistic
      :id="generateId(id, 'subsec-teststatistic')"
      :bio-stats-data="getAllBioStatsData"
    />
    <SectionNoofSimulations
      :id="generateId(id, 'subsec-noofsimulations')"
      :bio-stats-data="getAllBioStatsData"
    />
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import SectionBanner from "@/components/finalcomponents/SectionBanner.vue";
import SectionHypothesis from "@/components/finalcomponents/SectionHypothesis.vue";
import SectionTestType from "@/components/finalcomponents/SectionTestType.vue";
import SectionTailType from "@/components/finalcomponents/SectionTailType.vue";
import SectionTotalNoofEvents from "@/components/finalcomponents/SectionTotalNoofEvents.vue";
import SectionTypeIError from "@/components/finalcomponents/SectionTypeIError.vue";
import SectionTestStatistic from "@/components/finalcomponents/SectionTestStatistic.vue";
import SectionNoofSimulations from "@/components/finalcomponents/SectionNoofSimulations.vue";

export default {
  name: "SectionBiostats",
  components: {
    SectionBanner,
    SectionHypothesis,
    SectionTestType,
    SectionTailType,
    SectionTotalNoofEvents,
    SectionTypeIError,
    SectionTestStatistic,
    SectionNoofSimulations
  },
  props: {
    bioStatsData: { type: Array, default: () => [] },
    id: { type: String, default: "" }
  },
  computed: {
    ...mapGetters(["getAllBioStatsData"])
  },
  methods: {
    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
