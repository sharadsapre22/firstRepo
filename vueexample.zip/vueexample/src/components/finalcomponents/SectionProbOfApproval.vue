<template>
  <b-row :id="generateId(id, 'r0')" class="data">
    <b-col :id="generateId(id, 'r0c0')" class="col-3">
      Probability of Approval
    </b-col>
    <b-col
      v-for="(item, index) in regulatoryCollection"
      :id="generateId(id, 'r0c' + (index + 1))"
      :key="index"
    >
      <BaseTextBox
        :id="generateId(id, 'r0c' + (index + 1) + '-probofapproval')"
        :reference-id="item.designId"
        :value="item.data.probofApproval"
        @blur="onUpdateProbOfApproval"
        @input="onUpdateProbOfApproval"
      />
    </b-col>
  </b-row>
</template>

<script>
import { mapActions } from "vuex";
import BaseTextBox from "@/components/commoncontrols/BaseTextBox.vue";
import * as actionTypes from "@/constants/action-types";

export default {
  name: "SectionProbOfApproval",
  components: {
    BaseTextBox
  },
  props: {
    id: { type: String, default: "" },
    regulatoryCollection: { type: Array, default: () => [] }
  },
  methods: {
    ...mapActions([actionTypes.updateProbOfApproval]),
    onUpdateProbOfApproval(value, referenceId) {
      this.updateProbOfApproval({ paramVal: value, referenceId: referenceId });
    },
    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
