<template>
  <div :id="generateId(id, '')" class="ia-section">
    <SectionBanner
      :id="generateId(id, 'subsec-banner')"
      banner-name="Safety &amp; Regulatory"
    />
    <SectionPersonYearsExposure
      :id="generateId(id, 'subsec-personyearsexposure')"
      :safety-regulatory-data="getAllSafetyRegulatoryData"
    />
  </div>
</template>

<script>
import { mapGetters } from "vuex";

import SectionBanner from "@/components/finalcomponents/SectionBanner.vue";
import SectionPersonYearsExposure from "@/components/finalcomponents/SectionPersonYearsExposure.vue";

export default {
  name: "SectionSafetyAndRegulatory",
  components: {
    SectionBanner,
    SectionPersonYearsExposure
  },
  props: {
    id: { type: String, default: "" },
    safetyRegulatoryData: { type: Array, default: () => [] }
  },
  computed: {
    ...mapGetters(["getAllSafetyRegulatoryData"])
  },
  methods: {
    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
