<template>
  <b-row :id="generateId(id, 'r0')" class="data">
    <b-col :id="generateId(id, 'r0c0')" class="col-3">
      Patent Life at Trial Start
    </b-col>
    <b-col
      v-for="(item, index) in commercialData"
      :id="generateId(id, 'r0c' + (index + 1))"
      :key="index"
    >
      <BaseTextBox
        :id="generateId(id, 'r0c' + (index + 1) + '-patentlifeattrialstart')"
        :reference-id="item.designId"
        :value="item.data.patentLifeAtTrialStart"
        @blur="onUpdatePatentLifeAtTrialStart"
        @input="onUpdatePatentLifeAtTrialStart"
      />
    </b-col>
  </b-row>
</template>

<script>
import { mapActions } from "vuex";
import * as actionTypes from "@/constants/action-types";
import BaseTextBox from "@/components/commoncontrols/BaseTextBox.vue";

export default {
  name: "SectionPatentLifeAtTrialStart",
  components: {
    BaseTextBox
  },
  props: {
    id: { type: String, default: "" },
    commercialData: { type: Array, default: () => [] }
  },
  methods: {
    ...mapActions([actionTypes.updatePatentLifeAtTrialStart]),

    onUpdatePatentLifeAtTrialStart(value, referenceId) {
      this.updatePatentLifeAtTrialStart({
        paramVal: value,
        referenceId: referenceId
      });
    },

    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
