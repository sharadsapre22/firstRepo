<template>
  <b-row :id="generateId(id, 'r0')" class="data">
    <b-col :id="generateId(id, 'r0c0')" class="col-3">
      Number of Simulations
    </b-col>
    <b-col
      v-for="(item, index) in bioStatsData"
      :id="generateId(id, 'r0c' + (index + 1))"
      :key="index"
    >
      <BaseTextBox
        :id="generateId(id, 'r0c' + (index + 1) + '-noofsimulations')"
        :reference-id="item.designId"
        :value="item.data.noofSimulations"
        @blur="onUpdateNoofSimulations"
        @input="onUpdateNoofSimulations"
      />
    </b-col>
  </b-row>
</template>

<script>
import { mapActions } from "vuex";
import * as actionTypes from "@/constants/action-types";
import BaseTextBox from "@/components/commoncontrols/BaseTextBox.vue";

export default {
  name: "SectionNoofSimulations",
  components: {
    BaseTextBox
  },
  props: {
    id: { type: String, default: "" },
    bioStatsData: { type: Array, default: () => [] }
  },
  methods: {
    ...mapActions([actionTypes.updateNoofSimulations]),

    onUpdateNoofSimulations(value, referenceId) {
      this.updateNoofSimulations({ paramVal: value, referenceId: referenceId });
    },

    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
