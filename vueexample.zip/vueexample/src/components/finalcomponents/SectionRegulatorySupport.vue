<template>
  <div :id="generateId(id, '')" class="ia-section">
    <SectionBanner
      :id="generateId(id, 'subsec-banner')"
      banner-name="Regulatory Support"
    />
    <SectionRegReviewPeriod
      :id="generateId(id, 'subsec-regreviewperiod')"
      :regulatory-collection="regulatoryCollection"
    />
    <SectionProbOfApproval
      :id="generateId(id, 'subsec-regprobofapproval')"
      :regulatory-collection="regulatoryCollection"
    />
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import SectionBanner from "@/components/finalcomponents/SectionBanner.vue";
import SectionRegReviewPeriod from "@/components/finalcomponents/SectionRegReviewPeriod.vue";
import SectionProbOfApproval from "@/components/finalcomponents/SectionProbOfApproval.vue";

export default {
  name: "SectionRegulatorySupport",
  components: {
    SectionBanner,
    SectionRegReviewPeriod,
    SectionProbOfApproval
  },
  props: {
    id: { type: String, default: "" },
    regulatoryCollection: { type: Array, default: () => [] }
  },
  computed: {
    ...mapGetters(["getAllRegulatoryCollection"])
  },
  methods: {
    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
