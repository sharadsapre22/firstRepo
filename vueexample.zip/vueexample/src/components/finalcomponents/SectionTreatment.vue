<template>
  <div :id="generateId(id, '')" class="ia-section">
    <SectionBanner
      :id="generateId(id, 'subsec-banner')"
      banner-name="Treatment"
    />
    <SectionTreatmentArm
      :id="generateId(id, 'subsec-treatmentarms')"
      :treatment-collection="treatmentCollection"
    />
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import SectionBanner from "@/components/finalcomponents/SectionBanner.vue";
import SectionTreatmentArm from "@/components/finalcomponents/SectionTreatmentArm.vue";

export default {
  name: "SectionTreatment",
  components: {
    SectionBanner,
    SectionTreatmentArm
  },
  props: {
    id: { type: String, default: "" },
    treatmentCollection: { type: Array, default: () => [] }
  },
  computed: {
    ...mapGetters(["getAllTreatmentCollection"])
  },
  methods: {
    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
