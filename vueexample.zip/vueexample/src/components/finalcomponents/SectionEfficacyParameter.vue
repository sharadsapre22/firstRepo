<template>
  <b-row class="data">
    <b-col>
      Efficacy - Parameter
    </b-col>
    <b-col v-for="(item, index) in [1, 2, 3]" :key="index">
      <BaseComboBox />
    </b-col>
  </b-row>
</template>

<script>
import BaseComboBox from "@/components/commoncontrols/BaseComboBox.vue";
export default {
  name: "SectionEfficacyParameter",
  components: {
    BaseComboBox
  }
};
</script>

<style></style>
