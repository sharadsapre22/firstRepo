<template>
  <b-row :id="generateId(id, 'r0')" class="data">
    <b-col :id="generateId(id, 'r0c0')" class="col-3">
      Regulatory Review Period
    </b-col>
    <b-col
      v-for="(item, index) in regulatoryCollection"
      :id="generateId(id, 'r0c' + (index + 1))"
      :key="index"
    >
      <BaseTextBox
        :id="generateId(id, 'r0c' + (index + 1) + '-regreviewperiod')"
        :reference-id="item.designId"
        :value="item.data.regulatoryreviewperiod"
        @blur="onUpdateRegReviewPeriod"
        @input="onUpdateRegReviewPeriod"
      />
    </b-col>
  </b-row>
</template>

<script>
import { mapActions } from "vuex";
import BaseTextBox from "@/components/commoncontrols/BaseTextBox.vue";
import * as actionTypes from "@/constants/action-types";

export default {
  name: "SectionRegViewPeriod",
  components: {
    BaseTextBox
  },
  props: {
    id: { type: String, default: "" },
    regulatoryCollection: { type: Array, default: () => [] }
  },
  methods: {
    ...mapActions([actionTypes.updateRegulatoryReviewPeriod]),
    onUpdateRegReviewPeriod(value, referenceId) {
      this.updateRegulatoryReviewPeriod({
        paramVal: value,
        referenceId: referenceId
      });
    },
    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
