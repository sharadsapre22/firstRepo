<template>
  <b-row :id="generateId(id, 'r0')" class="data">
    <b-col :id="generateId(id, 'r0c0')" class="col-3">
      Person-Years Exposure
    </b-col>
    <b-col
      v-for="(item, index) in safetyRegulatoryData"
      :id="generateId(id, 'r0c' + (index + 1))"
      :key="index"
    >
      <div
        :id="generateId(id, 'r0c' + (index + 1) + '-pt1')"
        class="form-group h-25"
      >
        <b-row
          :id="generateId(id, 'r0c' + (index + 1) + '-pt1-r0')"
          class="h-25"
        >
          <b-col
            :id="generateId(id, 'r0c' + (index + 1) + '-pt1-r0c0')"
            class="border-0"
            style="padding-top:3px;"
          >
            <label
              :id="generateId(id, 'r0c' + (index + 1) + '-pt1-r0c0-pat1lbl')"
              for=""
              >Patients</label
            >
            <BaseTextBox
              :id="generateId(id, 'r0c' + (index + 1) + '-pt1-r0c0-pat1inp')"
              :reference-id="item.designId"
              :value="item.data.patientOne"
              @blur="onUpdatePatientOne"
              @input="onUpdatePatientOne"
            />
          </b-col>
          <b-col
            :id="generateId(id, 'r0c' + (index + 1) + '-pt1-r0c1')"
            class="border-0"
            style="padding-top:1px;"
          >
            <label
              :id="generateId(id, 'r0c' + (index + 1) + '-pt1-r0c1-time1lbl')"
              for=""
              >Months</label
            >
            <BaseTextBox
              :id="generateId(id, 'r0c' + (index + 1) + '-pt1-r0c1-time1inp')"
              :reference-id="item.designId"
              :value="item.data.timeOne"
              @blur="onUpdateTimeOne"
              @input="onUpdateTimeOne"
            />
          </b-col>
        </b-row>
      </div>
      <div
        :id="generateId(id, 'r0c' + (index + 1) + '-pt2')"
        class="form-group h-25"
      >
        <b-row
          :id="generateId(id, 'r0c' + (index + 1) + '-pt2-r0')"
          class="h-25"
        >
          <b-col
            :id="generateId(id, 'r0c' + (index + 1) + '-pt2-r0c0')"
            class="border-0"
            style="padding-top:3px;"
          >
            <label
              :id="generateId(id, 'r0c' + (index + 1) + '-pt2-r0c0-pat2lbl')"
              for=""
              >Patients</label
            >
            <BaseTextBox
              :id="generateId(id, 'r0c' + (index + 1) + '-pt2-r0c0-pat2inp')"
              :reference-id="item.designId"
              :value="item.data.patientTwo"
              @blur="onUpdatePatientTwo"
              @input="onUpdatePatientTwo"
            />
          </b-col>
          <b-col
            :id="generateId(id, 'r0c' + (index + 1) + '-pt2-r0c1')"
            class="border-0"
            style="padding-top:1px;"
          >
            <label
              :id="generateId(id, 'r0c' + (index + 1) + '-pt2-r0c1-time2lbl')"
              for=""
              >Months</label
            >
            <BaseTextBox
              :id="generateId(id, 'r0c' + (index + 1) + '-pt2-r0c1-time2inp')"
              :reference-id="item.designId"
              :value="item.data.timeTwo"
              @blur="onUpdateTimeTwo"
              @input="onUpdateTimeTwo"
            />
          </b-col>
        </b-row>
      </div>
    </b-col>
  </b-row>
</template>

<script>
import { mapActions } from "vuex";
import BaseTextBox from "@/components/commoncontrols/BaseTextBox.vue";
import * as actionTypes from "@/constants/action-types";

export default {
  name: "SectionPersonYearsExposure",
  components: {
    BaseTextBox
  },
  props: {
    id: { type: String, default: "" },
    safetyRegulatoryData: { type: Array, default: () => [] }
  },
  methods: {
    ...mapActions([
      actionTypes.updatePatientOne,
      actionTypes.updatePatientTwo,
      actionTypes.updateTimeOne,
      actionTypes.updateTimeTwo
    ]),
    onUpdatePatientOne(value, referenceId) {
      this.updatePatientOne({ paramVal: value, referenceId: referenceId });
    },
    onUpdatePatientTwo(value, referenceId) {
      this.updatePatientTwo({ paramVal: value, referenceId: referenceId });
    },
    onUpdateTimeOne(value, referenceId) {
      this.updateTimeOne({ paramVal: value, referenceId: referenceId });
    },
    onUpdateTimeTwo(value, referenceId) {
      this.updateTimeTwo({ paramVal: value, referenceId: referenceId });
    },
    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
