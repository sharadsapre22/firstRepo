<template>
  <b-row :id="generateId(id, 'r0')" class="title">
    <b-col :id="generateId(id, 'r0c0')" class="col-3">
      <h5 :id="generateId(id, 'r0c0-title')">{{ bannerName }}</h5>
    </b-col>
    <b-col :id="generateId(id, 'r0c1')"></b-col>
  </b-row>
</template>

<script>
export default {
  name: "SectionBanner",
  props: {
    bannerName: { type: String, default: "" },
    noofCols: { type: Array, default: () => [] },
    id: { type: String, default: "" }
  },
  methods: {
    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
