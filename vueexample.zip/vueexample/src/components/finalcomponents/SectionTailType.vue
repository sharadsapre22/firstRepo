<template>
  <b-row :id="generateId(id, 'r0')" class="data">
    <b-col :id="generateId(id, 'r0c0')" class="col-3">
      Tail Type
    </b-col>
    <!-- TODO (PK): Implementation of v-Model is pending -->
    <b-col
      v-for="(item, index) in bioStatsData"
      :id="generateId(id, 'r0c' + (index + 1))"
      :key="index"
    >
      <BaseComboBox
        :id="generateId(id, 'r0c' + (index + 1) + '-tailtype')"
        :reference-id="item.designId"
        :options="options"
        :value="item.data.tailType"
        @change="onUpdateTailType"
      />
    </b-col>
  </b-row>
</template>

<script>
import { mapActions } from "vuex";
import * as actionTypes from "@/constants/action-types";
import BaseComboBox from "@/components/commoncontrols/BaseComboBox.vue";

export default {
  name: "SectionTailType",
  components: {
    BaseComboBox
  },
  props: {
    id: { type: String, default: "" },
    bioStatsData: { type: Array, default: () => [] }
  },
  data() {
    return {
      options: [
        { value: "Left-tail", text: "Left-tail" },
        { value: "Right-tail", text: "Right-tail" }
      ]
    };
  },
  methods: {
    ...mapActions([actionTypes.updateTailType]),

    onUpdateTailType(value, referenceId) {
      this.updateTailType({ paramVal: value, referenceId: referenceId });
    },

    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
