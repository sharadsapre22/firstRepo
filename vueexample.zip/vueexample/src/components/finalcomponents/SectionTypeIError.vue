<template>
  <b-row :id="generateId(id, 'r0')" class="data">
    <b-col :id="generateId(id, 'r0c0')" class="col-3">
      Type 1 Error (alpha)
    </b-col>
    <b-col
      v-for="(item, index) in bioStatsData"
      :id="generateId(id, 'r0c' + (index + 1))"
      :key="index"
    >
      <BaseTextBox
        :id="generateId(id, 'r0c' + (index + 1) + '-typeIerror')"
        :reference-id="item.designId"
        :value="item.data.typeIError"
        @blur="onUpdateTypeIError"
        @input="onUpdateTypeIError"
      />
    </b-col>
  </b-row>
</template>

<script>
import { mapActions } from "vuex";
import * as actionTypes from "@/constants/action-types";
import BaseTextBox from "@/components/commoncontrols/BaseTextBox.vue";

export default {
  name: "SectionTypeIError",
  components: {
    BaseTextBox
  },
  props: {
    id: { type: String, default: "" },
    bioStatsData: { type: Array, default: () => [] }
  },
  methods: {
    ...mapActions([actionTypes.updateTypeIError]),

    onUpdateTypeIError(value, referenceId) {
      this.updateTypeIError({ paramVal: value, referenceId: referenceId });
    },

    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
