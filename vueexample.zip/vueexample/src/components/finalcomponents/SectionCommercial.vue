<template>
  <div :id="generateId(id, '')" class="ia-section">
    <SectionBanner
      :id="generateId(id, 'subsec-banner')"
      banner-name="Commercial"
    />
    <SectionAvgCostPerPatient
      :id="generateId(id, 'subsec-avgcostperpatient')"
      :commercial-data="getAllCommercialData"
    />
    <SectionDevelopmentCost
      :id="generateId(id, 'subsec-developmentcost')"
      :commercial-data="getAllCommercialData"
    />
    <SectionMaxTrialCost
      :id="generateId(id, 'subsec-maxtrialcost')"
      :commercial-data="getAllCommercialData"
    />
    <SectionHazardRatioLimit
      :id="generateId(id, 'subsec-hazardratiolimit')"
      :commercial-data="getAllCommercialData"
    />
    <SectionPatentLifeAtTrialStart
      :id="generateId(id, 'subsec-patentlifeattrialstart')"
      :commercial-data="getAllCommercialData"
    />
    <SectionPeakNetRevenue
      :id="generateId(id, 'subsec-peaknetrevenue')"
      :commercial-data="getAllCommercialData"
    />
    <SectionDiscountRate
      :id="generateId(id, 'subsec-discountrate')"
      :commercial-data="getAllCommercialData"
    />
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import SectionBanner from "@/components/finalcomponents/SectionBanner.vue";
import SectionAvgCostPerPatient from "@/components/finalcomponents/SectionAvgCostPerPatient.vue";
import SectionDevelopmentCost from "@/components/finalcomponents/SectionDevelopmentCost.vue";
import SectionMaxTrialCost from "@/components/finalcomponents/SectionMaxTrialCost.vue";
import SectionHazardRatioLimit from "@/components/finalcomponents/SectionHazardRatioLimit.vue";
import SectionPatentLifeAtTrialStart from "@/components/finalcomponents/SectionPatentLifeAtTrialStart.vue";
import SectionPeakNetRevenue from "@/components/finalcomponents/SectionPeakNetRevenue.vue";
import SectionDiscountRate from "@/components/finalcomponents/SectionDiscountRate.vue";

export default {
  name: "SectionCommercial",
  components: {
    SectionBanner,
    SectionAvgCostPerPatient,
    SectionDevelopmentCost,
    SectionMaxTrialCost,
    SectionHazardRatioLimit,
    SectionPatentLifeAtTrialStart,
    SectionPeakNetRevenue,
    SectionDiscountRate
  },
  props: {
    id: { type: String, default: "" },
    commercialData: { type: Array, default: () => [] }
  },
  computed: {
    ...mapGetters(["getAllCommercialData"])
  },
  methods: {
    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
