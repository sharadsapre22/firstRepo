<template>
  <b-row class="data">
    <b-col>
      Futility - Binding
    </b-col>
    <b-col v-for="(item, index) in [1, 2, 3]" :key="index">
      <BaseTextBox />
    </b-col>
  </b-row>
</template>

<script>
import BaseTextBox from "@/components/commoncontrols/BaseTextBox.vue";
export default {
  name: "SectionFutilityBinding",
  components: {
    BaseTextBox
  }
};
</script>

<style></style>
