<template>
  <div :id="generateId(id, '')">
    <b-card :id="generateId(id, 'card')" class="border-0">
      <b-card-sub-title :id="generateId(id, 'card-subtitle')">{{
        designOption
      }}</b-card-sub-title>
    </b-card>
  </div>
</template>

<script>
export default {
  name: "SectionSingleDesignOption",
  props: {
    designOption: { type: String, default: "2-arm Logrank Fixed" },
    id: { type: String, default: "" }
  },
  methods: {
    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
