<template>
  <b-row :id="generateId(id, 'r0')" class="data">
    <b-col :id="generateId(id, 'r0c0')" class="col-3">
      Treatment Arms
    </b-col>
    <b-col
      v-for="(item, index) in treatmentCollection"
      :id="generateId(id, 'r0c' + (index + 1))"
      :key="index"
    >
      <label :id="generateId(id, 'r0c' + (index + 1) + '-treatmentlbl')" for=""
        >Treatment</label
      >
      <BaseTextBox
        :id="generateId(id, 'r0c' + (index + 1) + '-treatment')"
        :reference-id="item.designId"
        :value="item.data.treatment"
        @blur="onUpdateTreatment"
        @input="onUpdateTreatment"
      />
      <label :id="generateId(id, 'r0c' + (index + 1) + '-controllbl')" for=""
        >Control</label
      >
      <BaseTextBox
        :id="generateId(id, 'r0c' + (index + 1) + '-control')"
        :reference-id="item.designId"
        :value="item.data.control"
        @blur="onUpdateControl"
        @input="onUpdateControl"
      />
    </b-col>
  </b-row>
</template>

<script>
import { mapActions } from "vuex";
import BaseTextBox from "@/components/commoncontrols/BaseTextBox.vue";
import * as actionTypes from "@/constants/action-types";

export default {
  name: "SectionTreatmentArm",
  components: {
    BaseTextBox
  },
  props: {
    id: { type: String, default: "" },
    treatmentCollection: { type: Array, default: () => [] }
  },
  methods: {
    ...mapActions([actionTypes.updateTreatment, actionTypes.updateControl]),
    onUpdateTreatment(value, referenceId) {
      this.updateTreatment({ paramVal: value, referenceId: referenceId });
    },
    onUpdateControl(value, referenceId) {
      this.updateControl({ paramVal: value, referenceId: referenceId });
    },
    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
