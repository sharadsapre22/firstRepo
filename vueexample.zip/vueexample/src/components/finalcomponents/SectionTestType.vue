<template>
  <b-row :id="generateId(id, 'r0')" class="data">
    <b-col :id="generateId(id, 'r0c0')" class="col-3">
      Test Type
    </b-col>
    <b-col
      v-for="(item, index) in bioStatsData"
      :id="generateId(id, 'r0c' + (index + 1))"
      :key="index"
    >
      <BaseTextBox
        :id="generateId(id, 'r0c' + (index + 1) + '-testtype')"
        :reference-id="item.designId"
        :value="item.data.testType"
        :disabled="true"
        @blur="onUpdateTestType"
        @input="onUpdateTestType"
      />
    </b-col>
  </b-row>
</template>

<script>
import { mapActions } from "vuex";
import * as actionTypes from "@/constants/action-types";
import BaseTextBox from "@/components/commoncontrols/BaseTextBox.vue";

export default {
  name: "SectionTestType",
  components: {
    BaseTextBox
  },
  props: {
    id: { type: String, default: "" },
    bioStatsData: { type: Array, default: () => [] }
  },
  methods: {
    ...mapActions([actionTypes.updateTestType]),

    onUpdateTestType(value, referenceId) {
      this.updateTestType({ paramVal: value, referenceId: referenceId });
    },

    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
