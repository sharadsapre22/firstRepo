<template>
  <div :id="generateId(id, '')" class="ia-header">
    <b-row :id="generateId(id, 'r0')">
      <b-col :id="generateId(id, 'r0c0')" class="col-3"></b-col>
      <b-col
        v-for="(item, index) in designOptions"
        :id="generateId(id, 'r0c' + (index + 1))"
        :key="index"
      >
        <SectionSingleDesignOption
          :id="generateId(id, 'r0c' + (index + 1) + '-designoption')"
          :design-option="item"
        />
      </b-col>
    </b-row>
  </div>
</template>

<script>
import SectionSingleDesignOption from "@/components/finalcomponents/SectionSingleDesignOption.vue";
export default {
  name: "SectionDesignOptions",
  components: {
    SectionSingleDesignOption
  },
  props: {
    id: { type: String, default: "" }
  },
  data() {
    return {
      designOptions: [
        "2-arm Logrank Fixed"
        // "2-arm Logrank Group Seq.",
        // "2-arm Logrank Group Seq. with SSR"
      ]
    };
  },
  methods: {
    generateId(id, suffix) {
      if (suffix === "") return id;
      return id + "-" + suffix;
    }
  }
};
</script>

<style></style>
