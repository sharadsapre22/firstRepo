<template>
  <div id="designadvisor-purpose">
    <b-container class="pt-5 mt-5">
      <h4>Purpose</h4>
      <b-card class="btn-group-toggle" data-toggle="buttons">
        <b-row>
          <b-col class="text-center">
            <button
              id="designadvisor-purpose-confirm"
              type="button"
              class="btn btn-light"
              @click="pushRadio('confirm')"
            >
              Confirmatory
            </button>
          </b-col>
          <b-col class="text-center">
            <button
              id="designadvisor-purpose-poc"
              type="button"
              class="btn btn-light"
              @click="pushRadio('poc')"
            >
              Exploratory POC
            </button>
          </b-col>
        </b-row>
        <b-row>
          <b-col class="text-center">
            <button
              id="designadvisor-purpose-safety"
              type="button"
              class="btn btn-light"
              @click="pushRadio('safety')"
            >
              Exploratory Safety
            </button>
          </b-col>
          <b-col class="text-center">
            <button
              id="designadvisor-purpose-poc-safety"
              type="button"
              class="btn btn-light"
              @click="pushRadio('poc-safety')"
            >
              Exploratory POC and Safety
            </button>
          </b-col>
        </b-row>
      </b-card>
      <b-card-footer id="designadvisor-purpose-footer" class="text-center">
        <button
          :id="buttonNextId"
          type="button"
          class="btn btn-primary btn-sm"
          :disabled="selected === ''"
          @click="scrollNext"
        >
          Next
        </button>
      </b-card-footer>
    </b-container>
  </div>
</template>

<script>
import { eventBus } from "../main";
import { mapActions } from "vuex";
import designs from "@/data/all_designs";

const root_id = "designadvisor-purpose";
//const next_card_id = "designadvisor-groups";
const next_card_id = "recommendations";
export default {
  name: "Purpose",
  data: function() {
    return {
      selected: "",
      purposes: ["confirm", "poc", "safety", "poc-safety"],
      filereader: {
        csvfilename: "",
        csvdata: []
      }
    };
  },
  computed: {
    buttonNextId() {
      return root_id + "-next";
    },
    buttonId(val) {
      return root_id + "-" + val;
    }
  },
  methods: {
    ...mapActions(["selectPurpose", "selectRecommendations"]),
    // None or exactly one button selected
    pushRadio(val) {
      if (this.selected == val) {
        this.selected = "";
        const elem = document.getElementById(root_id + "-" + val);
        elem.className = elem.className.replace("btn-info", "btn-light");
        document.getElementById(this.buttonNextId);
      } else {
        this.selected = val;
        this.purposes.forEach(x => {
          const elem = document.getElementById(root_id + "-" + x);
          elem.className =
            x == val
              ? elem.className.replace("btn-light", "btn-info")
              : elem.className.replace("btn-info", "btn-light");
        });
      }
    },
    filterDesigns() {
      const required = this.selected.split("-");
      let filtered = designs;
      required.forEach(purpose => {
        filtered = filtered.filter(design => design.purpose.includes(purpose));
      });
      eventBus.$emit("onRecommendations", JSON.stringify(filtered));
      this.selectRecommendations(filtered);
      return filtered;
    },
    scrollNext() {
      this.selectPurpose(this.selected);
      const recommended = this.filterDesigns();
      const elem = document.getElementById(next_card_id);
      if (!elem || typeof elem !== "undefined") {
        elem.scrollIntoView();
      }
      return recommended;
    }
  }
};
</script>
