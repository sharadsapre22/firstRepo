<template>
  <div id="ia" class="container mt-5 mb-5">
    <SectionDesignOptions id="ia-sec-designoptions" />
    <SectionStudyDesign
      id="ia-sec-studydesign"
      :study-design-data="studyDesignData"
    />
    <SectionTreatment
      id="ia-sec-treatment"
      :treatment-collection="treatmentCollection"
    />
    <SectionAccrualMgmt
      id="ia-sec-accrualmgmt"
      :accrual-management-data="accrualManagementData"
    />
    <SectionSafetyAndRegulatory
      id="ia-sec-safetyregulatory"
      :safety-regulatory-data="safetyRegulatoryData"
    />
    <SectionRegulatorySupport
      id="ia-sec-regulatory"
      :regulatory-collection="regulatoryCollection"
    />
    <SectionBiostats id="ia-sec-biostats" :bio-stats-data="bioStatsData" />
    <SectionCommercial
      id="ia-sec-commercial"
      :commercial-data="commercialData"
    />
    <FileReader id="ia-sec-filereader" />
    <SectionSeedParams id="ia-sec-seedparams" />
  </div>
</template>

<script>
// @ is an alias to /src
//
import { mapActions } from "vuex";
import * as actionTypes from "@/constants/action-types";
import SampleDesignData from "@/data/sampleDesigns.js";

import SectionDesignOptions from "@/components/finalcomponents/SectionDesignOptions.vue";
import SectionStudyDesign from "@/components/StudyDesign/SectionStudyDesign.vue";
import SectionTreatment from "@/components/finalcomponents/SectionTreatment.vue";
import SectionAccrualMgmt from "@/components/SectionAccrualMgmt.vue";
import SectionSafetyAndRegulatory from "@/components/finalcomponents/SectionSafetyAndRegulatory.vue";
import SectionRegulatorySupport from "@/components/finalcomponents/SectionRegulatorySupport.vue";
import SectionBiostats from "@/components/finalcomponents/SectionBiostats.vue";
import SectionCommercial from "@/components/finalcomponents/SectionCommercial.vue";
import FileReader from "@/components/FileReader.vue";
import SectionSeedParams from "@/components/SectionSeedParams.vue";

export default {
  name: "InputAdvisor",
  components: {
    SectionDesignOptions,
    SectionStudyDesign,
    SectionTreatment,
    SectionAccrualMgmt,
    SectionSafetyAndRegulatory,
    SectionRegulatorySupport,
    SectionBiostats,
    SectionCommercial,
    FileReader,
    SectionSeedParams
  },
  data() {
    return {
      studyDesignData: "",
      treatmentCollection: "",
      accrualManagementData: "",
      safetyRegulatoryData: "",
      regulatoryCollection: "",
      bioStatsData: "",
      commercialData: ""
    };
  },
  created() {
    SampleDesignData.map(item => {
      this.accrualManagementData = [
        ...this.accrualManagementData,
        {
          data: item.accrualManagement,
          designId: item.designId,
          designTest: item.designTest
        }
      ];
      this.bioStatsData = [
        ...this.bioStatsData,
        {
          data: item.bioStats,
          designId: item.designId,
          designTest: item.designTest
        }
      ];
      this.commercialData = [
        ...this.commercialData,
        {
          data: item.commercial,
          designId: item.designId,
          designTest: item.designTest
        }
      ];
      this.safetyRegulatoryData = [
        ...this.safetyRegulatoryData,
        {
          data: item.safetyRegulatory,
          designId: item.designId,
          designTest: item.designTest
        }
      ];
      this.studyDesignData = [
        ...this.studyDesignData,
        {
          data: item.studyDesign,
          designId: item.designId,
          designTest: item.designTest
        }
      ];
      this.treatmentCollection = [
        ...this.treatmentCollection,
        {
          data: item.treatmentarms,
          designId: item.designId,
          designTest: item.designTest
        }
      ];
      this.regulatoryCollection = [
        ...this.regulatoryCollection,
        {
          data: item.regulatory,
          designId: item.designId,
          designTest: item.designTest
        }
      ];
    });

    this.fetchAccrualMgmtData(this.accrualManagementData);
    this.fetchStudyDesignData(this.studyDesignData);
    this.fetchBioStatsData(this.bioStatsData);
    this.fetchSafetyRegulatoryData(this.safetyRegulatoryData);
    this.fetchCommercialData(this.commercialData);
    this.fetchTreatmentCollection(this.treatmentCollection);
    this.fetchRegulatoryCollection(this.regulatoryCollection);
  },
  methods: {
    ...mapActions([
      actionTypes.fetchAccrualMgmtData,
      actionTypes.fetchBioStatsData,
      actionTypes.fetchSafetyRegulatoryData,
      actionTypes.fetchCommercialData,
      actionTypes.fetchTreatmentCollection,
      actionTypes.fetchRegulatoryCollection,
      actionTypes.fetchStudyDesignData
    ])
  }
};
</script>
