<template>
  <div id="designadvisor">
    <StrategicGoals id="designadvisor-strategicgoals" />
    <Purpose id="designadvisor-purpose" />
    <DesignRecommendations id="designadvisor-recommendations" />
  </div>
</template>

<script>
// @ is an alias to /src
import StrategicGoals from "@/components/StrategicGoals.vue";
import Purpose from "@/components/Purpose.vue";
import DesignRecommendations from "@/components/DesignRecommendations.vue";

export default {
  name: "DesignAdvisor",
  components: {
    StrategicGoals,
    Purpose,
    DesignRecommendations
  }
};
</script>
