import Vue from "vue";
import VueRouter from "vue-router";

Vue.use(VueRouter);

const routes = [
  {
    path: "/designadvisor",
    name: "Design Advisor",
    component: () => import("../views/DesignAdvisor.vue")
  },
  {
    path: "/inputadvisor",
    name: "about",
    component: () => import("../views/InputAdvisor.vue")
  },
  { path: "/simulation", redirect: "" },
  { path: "/tradeoffadvisor", redirect: "" },
  { path: "/", redirect: "/inputadvisor" }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
});

export default router;
