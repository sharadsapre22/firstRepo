// Time Unit
export const days = "Days";
export const weeks = "Weeks";
export const months = "Months";
export const years = "Years";
export const timeUnitsSupported = [days, weeks, months, years];

// Designs
export const twoArmLogrankFixed = "2-arm Logrank Fixed";
export const twoArmLogrankGrpSeq = "2-arm Logrank Group Seq.";
export const twoArmLogrankGrpSeqSSR = "2-arm Logrank Group Seq. with SSR";
export const designsSupported = [
  twoArmLogrankFixed,
  twoArmLogrankGrpSeq,
  twoArmLogrankGrpSeqSSR
];

// Survival Models
export const survModelExponential = "Exponential";
export const survModelsSupported = [survModelExponential];

// Survival Input Methods
export const survInpMthdMedSurvTime = "Medial Survival Time";
export const survInpMthdsSupported = [survInpMthdMedSurvTime];

// Dropout Rate Models
export const drpOutRateModelExponential = "Exponential";
export const drpOutRateModelsSupported = [drpOutRateModelExponential];

// Dropout Rate Input Methods
export const drpOutRateInpMthdProbofDropout = "Prob. of Dropout";
export const drpOutRateInpMthdsSupported = [drpOutRateInpMthdProbofDropout];

// Maximum Follow-up Time
export const followUpTypeEndofStudy = "End of Study";
export const followUpTypeFixed = "Fixed";
export const followUpTypesSupported = [
  followUpTypeEndofStudy,
  followUpTypeFixed
];

// Randomization Types
export const randomizationTypePure = "Pure";
export const randomizationTypesSupported = [randomizationTypePure];

// Hypothesis
export const hypothesisTypeSuperiority = "Superiority";
export const hypothesisTypesSupported = [hypothesisTypeSuperiority];

// Test Type
export const testTypeOneSided = "1-sided";
export const testTypeSupported = [testTypeOneSided];

// Test Statistic
export const testStatisticLogrank = "Logrank";
export const testStatisticSupported = [testStatisticLogrank];

// Random Seed Parameters
export const randomSeedTypeClock = "Clock";
export const randomSeedTypeFixed = "Fixed";

// Currency Constants
export const currencyMillion = "Million";
export const currencyBillion = "Billion";
export const currencyDoller = "$";
export const currencyDiscount = "%";
