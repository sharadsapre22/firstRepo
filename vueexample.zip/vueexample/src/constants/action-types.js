// Study Design
export const updateDesignTest = "updateDesignTest";
export const updateNoofIA = "updateNoofIA";
export const updatePercEventsAtIA = "updatePercEventsAtIA";
export const updateTimeUnit = "updateTimeUnit";
export const fetchStudyDesignData = "fetchStudyDesignData";
export const setStudyDesigns = "setStudyDesigns";

// Treatments
export const updateTreatment = "updateTreatment";
export const updateControl = "updateControl";
export const fetchTreatmentCollection = "fetchTreatmentCollection";
export const setTreatments = "setTreatments";

//Patients & Endpoints
export const updateAllocRatio = "updateAllocRatio";
export const updateSurvModel = "updateSurvModel";
export const updateSurvInputMethod = "updateSurvInputMethod";
export const updateSurvModelControl = "updateSurvModelControl";
export const updateSurvModelTreatment = "updateSurvModelTreatment";
export const updateSurvModelHazardRatio = "updateSurvModelHazardRatio";
export const updateDropoutRateModel = "updateDropoutRateModel";
export const updateDropoutRateInputMethod = "updateDropoutRateInputMethod";
export const updateDropoutRateControl = "updateDropoutRateControl";
export const updateDropoutRateTreatment = "updateDropoutRateTreatment";
export const updateDropoutRateByTime = "updateDropoutRateByTime";
export const updateMaxFollowUpTimeType = "updateMaxFollowUpTimeType";
export const updateFixedFollowUpTime = "updateFixedFollowUpTime";
export const setSurvModels = "setSurvModels";
export const fetchPatientEndpointData = "fetchPatientEndpointData";

// Accrual & Management
export const updateNoofPatients = "updateNoofPatients";
export const updateFirstPatientInDate = "updateFirstPatientInDate";
export const updateAvgPatientsPerTimeUnit = "updateAvgPatientsPerTimeUnit";
export const updateRandomizationType = "updateRandomizationType";
export const fetchAccrualMgmtData = "fetchAccrualMgmtData";

// Safety & Regulatory
export const updatePatientOne = "updatePatientOne";
export const updatePatientTwo = "updatePatientTwo";
export const updateTimeOne = "updateTimeOne";
export const updateTimeTwo = "updateTimeTwo";
export const fetchSafetyRegulatoryData = "fetchSafetyRegulatoryData";

// Regulatory Support
export const updateProbOfApproval = "updateProbOfApproval";
export const updateRegulatoryReviewPeriod = "updateRegulatoryReviewPeriod";
export const fetchRegulatoryCollection = "fetchRegulatoryCollection";

// Biostats
export const updateHypothesis = "updateHypothesis";
export const updateTestType = "updateTestType";
export const updateTailType = "updateTailType";
export const updateTotalNoofEvents = "updateTotalNoofEvents";
export const updateTypeIError = "updateTypeIError";
export const updateTestStatistic = "updateTestStatistic";
export const updateEfficacyBoundaryFamily = "updateEfficacyBoundaryFamily";
export const updateEfficacySpendingFunction = "updateEfficacySpendingFunction";
export const updateEfficacyParameter = "updateEfficacyParameter";
export const updateEfficacyTypeIError = "updateEfficacyTypeIError";
export const updateFutilityBinding = "updateFutilityBinding";
export const updateFutilityBoundaryFamily = "updateFutilityBoundaryFamily";
export const updateFutilityParameter = "updateFutilityParameter";
export const updateNoofSimulations = "updateNoofSimulations";
export const updateMaxNoofEventsIfAdapt = "updateMaxNoofEventsIfAdapt";
export const updateMaxSampleSizeIfAdapt = "updateMaxSampleSizeIfAdapt";
export const updateUpperLimitOnStudyDuration =
  "updateUpperLimitOnStudyDuration";
export const updateTargetCPForReestimatingEvents =
  "updateTargetCPForReestimatingEvents";
export const updatePromisingZoneMinCP = "updatePromisingZoneMinCP";
export const updatePromisingZoneMaxCP = "updatePromisingZoneMaxCP";
export const fetchBioStatsData = "fetchBioStatsData";

// Commercial
export const updateAvgCostPerPatient = "updateAvgCostPerPatient";
export const updateDevelopmentCost = "updateDevelopmentCost";
export const updateMaxTrialCost = "updateMaxTrialCost";
export const updateHazardRatioLimit = "updateHazardRatioLimit";
export const updatePatentLifeAtTrialStart = "updatePatentLifeAtTrialStart";
export const updatePeakNetRevenue = "updatePeakNetRevenue";
export const updateDiscountRate = "updateDiscountRate";
export const fetchCommercialData = "fetchCommercialData";

// Seed Parameters
export const updateSeedType = "updateSeedType";
export const updateFixedSeed = "updateFixedSeed";
export const fetchSeedParams = "fetchSeedParams";
export const setSeedParams = "setSeedParams";
