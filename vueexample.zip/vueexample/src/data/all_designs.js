let designs = [
  { name: "Single arm; Fixed", purpose: ["confirm", "safety", "poc"] },
  {
    name: "Single arm ; Early Stopping Efficacy",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Single arm ; Early Stopping Futility",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Single arm; Early Stopping Efficacy & Futility",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Single arm; Unblinded Sample Size Re-estimation",
    purpose: ["confirm", "safety", "poc"]
  },
  { name: "Two-arm; Fixed", purpose: ["confirm", "safety", "poc"] },
  {
    name: "Two-arm; Early Stopping Efficacy",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Two-arm; Early Stopping Futility",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Two arm; Early Stopping Efficacy & Futility",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Two-arm; Blinded Sample Size Re-estimation",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Two-arm; Unblinded Sample Size Re-estimation",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name:
      "Two-arm ; Unblinded Sample Size Re-estimation with Surrogate Endpoint",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Two-arm; Population Enrichment",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Two-arm; Biomarker adaptive",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Two-arm; Non-Inferiority to Superiority",
    purpose: ["confirm", "safety", "poc"]
  },
  { name: "Multiple-arm; Fixed", purpose: ["confirm", "safety", "poc"] },
  {
    name: "Multiple-arm; Early Stopping Efficacy",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Multiple-arm; Early Stopping Futility",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Multiple-arm; Early Stopping Efficacy & Futility",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Multiple-arm; Blinded Sample Size Re-estimation",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Multiple-arm; Unblinded Sample Size Re-estimation",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name:
      "Multiple-arm; Unblinded Sample Size Re-estimation with Surrogate Endpoint",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Multiple-arm; Dose Selection",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Multiple-arm; Dose Selection with Surrogate Endpoint",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Multiple-arm; Biomarker adaptive",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Multiple-arm; Multi-arm multi-stage",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Multiple-arm; Multi-arm multi-stage with Surrogate Endpoint",
    purpose: ["confirm", "safety", "poc"]
  },
  {
    name: "Single-arm binomial; Simon Two-stage design",
    purpose: ["safety", "poc"]
  },
  {
    name:
      "Single-arm binomial; Bayesian predictive probability futility stopping",
    purpose: ["safety", "poc"]
  },
  { name: "Single-agent; Dose Escalation; 3+3", purpose: ["safety", "poc"] },
  { name: "Single-agent; Dose Escalation; mTPI", purpose: ["safety", "poc"] },
  { name: "Single-agent; Dose Escalation; CRM", purpose: ["safety", "poc"] },
  { name: "Single-agent; Dose Escalation; BLRM", purpose: ["safety", "poc"] },
  { name: "Single-agent; Dose Escalation; BOIN", purpose: ["safety", "poc"] },
  {
    name: "Single-agent; Dose Escalation; TITE CRM",
    purpose: ["safety", "poc"]
  },
  {
    name: "Single-agent; Dose Escalation; Accelerated Titration",
    purpose: ["safety", "poc"]
  },
  { name: "Dual-agent; Dose Escalation; BLRM", purpose: ["safety", "poc"] },
  { name: "Dual-agent; Dose Escalation; PIPE", purpose: ["safety", "poc"] },
  { name: "Dose-Escalation; EffTox", purpose: ["safety", "poc"] },
  { name: "Dose-Escalation; TEPI", purpose: ["safety", "poc"] },
  { name: "Multi-arm; basket trial", purpose: ["safety", "poc"] }
];
export default designs;
