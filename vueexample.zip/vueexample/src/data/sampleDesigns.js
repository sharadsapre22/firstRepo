let sampleDesignData = [
  {
    designId: "1",
    designTest: "2-arm Logrank Fixed",
    studyDesign: {
      noofIA: "0",
      percEventsAtIA: "0",
      timeUnit: "Months"
    },
    treatmentarms: {
      treatment: "Quizartinib",
      control: "Salvage Chemo"
    },
    patientEndpoints: {
      allocRatio: "1:1",
      survModel: "Exponential",
      survInputMethod: "Median Survival Time",
      survModelControl: "3.9",
      survModelTreatment: "6",
      survModelHazardRatio: "0.65",
      dropoutRateModel: "Exponential",
      dropoutRateInputMethod: "Prob. of Dropout",
      dropoutRateControl: "0.04",
      dropoutRateTreatment: "0.04",
      dropoutRateByTime: "1",
      maxFollowupTimeType: "End of Study",
      fixedFollowUpTime: "1"
    },
    accrualManagement: {
      noofPatients: "300",
      firstPatientInDate: "2020-12-01",
      avgPatientsPerTimeUnit: "19",
      randomizationType: "Pure"
    },
    safetyRegulatory: {
      patientOne: "50",
      patientTwo: "100",
      timeOne: "3",
      timeTwo: "12"
    },
    regulatory: {
      regulatoryreviewperiod: "12",
      probofApproval: "0.8"
    },
    bioStats: {
      hypothesis: "Superiority",
      testType: "1-sided",
      tailType: "Left-tail",
      totalNoofEvents: "350",
      typeIError: "0.05",
      testStatistic: "Logrank",
      efficacyBoundaryFamily: "Spending Functions",
      efficacySpendingFunction: "Gamma",
      efficacyParameter: "-4",
      efficacyTypeIError: "0.025",
      futilityBinding: "No",
      futilityBoundaryFamily: "Conditional Power",
      futilityParameter: "0.05",
      noofSimulations: "10000",
      maxNoofEventsIfAdapt: "1333",
      maxSampleSizeIfAdapt: "1333",
      upperLimitOnStudyDuration: "36",
      targetCPForReestimatingEvents: "0.9",
      promisingZoneMinCP: "0.3",
      promisingZoneMaxCP: "0.9"
    },
    commercial: {
      avgCostPerPatient: "10000",
      developmentCost: "100000",
      maxTrialCost: "10M",
      hazardRatioLimit: "0.8",
      patentLifeAtTrialStart: "10",
      peakNetRevenue: "10B",
      discountRate: "5"
    },
    seedParameters: {
      seedType: "Clock",
      fixedSeed: "0"
    }
  }
];
export default sampleDesignData;
