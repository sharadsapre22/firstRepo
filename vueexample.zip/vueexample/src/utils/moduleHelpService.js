const ModuleHelpService = {
  getItemIndex(arrModuleData, id) {
    return arrModuleData.findIndex(item => item.designId === id);
  },

  getItemAtIndex(arrModuleData, id) {
    return arrModuleData.find(item => item.designId === id);
  },

  getCurrencyNumberFromNotation(valueInput) {
    if (valueInput.includes("K")) {
      let currencyValue = valueInput
        .trim()
        .substr(0, valueInput.trim().length - 1);
      return parseFloat(currencyValue) * 1000;
    } else if (valueInput.includes("M")) {
      let currencyValue = valueInput
        .trim()
        .substr(0, valueInput.trim().length - 1);
      return parseFloat(currencyValue) * 1000000;
    } else if (valueInput.includes("B")) {
      let currencyValue = valueInput
        .trim()
        .substr(0, valueInput.trim().length - 1);
      return parseFloat(currencyValue) * 1000000000;
    } else if (valueInput.includes("T")) {
      let currencyValue = valueInput
        .trim()
        .substr(0, valueInput.trim().length - 1);
      return parseFloat(currencyValue) * 1000000000000;
    } else return valueInput;
  },

  getCurrencyNosFromCurrencyNotations(valueInput) {
    let rangeSpecified = valueInput.includes(":");
    let commaSpecified = valueInput.includes(",");
    let backupCurrencyValue = "";

    if (rangeSpecified == false && commaSpecified == false) {
      return this.getCurrencyNumberFromNotation(valueInput);
    } else {
      let splitArr = valueInput.trim().split(",");

      for (let i = 0; i < splitArr.length; i++) {
        let rangeSpecified = splitArr[i].includes(":");

        if (rangeSpecified && splitArr[i].split(":").length == 3) {
          let start = splitArr[i].split(":")[0];
          let end = splitArr[i].split(":")[1];
          let step = splitArr[i].split(":")[2];

          let startReplaceStr = this.getCurrencyNumberFromNotation(start);
          let endReplaceStr = this.getCurrencyNumberFromNotation(end);
          let stepReplaceStr = this.getCurrencyNumberFromNotation(step);

          backupCurrencyValue += startReplaceStr;
          backupCurrencyValue += ":";
          backupCurrencyValue += endReplaceStr;
          backupCurrencyValue += ":";
          backupCurrencyValue += stepReplaceStr;
        } else {
          let replaceStr = this.getCurrencyNumberFromNotation(splitArr[i]);
          backupCurrencyValue += replaceStr;
        }

        if (i !== splitArr.length - 1) backupCurrencyValue += ",";
      }
    }

    return backupCurrencyValue;
  },

  getRangeMultipleValues(start, end, step = 1) {
    if (isNaN(start) || isNaN(end) || isNaN(step)) return;

    var diff = Math.round((end - start) * 1000000000) / 1000000000;
    const intervals = Math.ceil(diff / (step == 0 ? 1 : step));
    const len = intervals == 0 ? 1 : intervals + 1;

    var arr = Array(len)
      .fill()
      .map((_, idx) =>
        Math.round((start + idx * step) * 1000000000) / 1000000000 > end
          ? end
          : Math.round((start + idx * step) * 1000000000) / 1000000000
      );

    return arr.filter((v, i, a) => a.indexOf(v) === i);
  },

  getMultipleValues(valueInput) {
    let rangeSpecified = valueInput.includes(":");
    let commaSpecified = valueInput.includes(",");

    if (rangeSpecified == false && commaSpecified == false) return [valueInput];

    let splitArr = valueInput.split(",");
    let multipleValArr = [];

    for (let i = 0; i < splitArr.length; i++) {
      let rangeSpecified = splitArr[i].includes(":");

      if (rangeSpecified && splitArr[i].split(":").length == 3) {
        let start = parseFloat(splitArr[i].split(":")[0]);
        let end = parseFloat(splitArr[i].split(":")[1]);
        let step = parseFloat(splitArr[i].split(":")[2]);

        multipleValArr = [
          ...multipleValArr,
          ...this.getRangeMultipleValues(start, end, step)
        ];
      } else {
        multipleValArr = [...multipleValArr, parseFloat(splitArr[i])];
      }
    }

    return multipleValArr;
  },

  getAllMultipleValueCombinations(arrays) {
    let result = arrays.reduce((a, b) =>
      a.reduce((r, v) => r.concat(b.map(w => [].concat(v, w))), [])
    );
    return result.map(a => a.join("@"));
  },

  generateId(id, suffix) {
    return id + "_" + suffix;
  },

  getFutureDate(dateStr, offset, timeunit) {
    let date = new Date(dateStr);
    let convertOffsetToDays = offset;

    switch (timeunit) {
      case "Days":
        {
          convertOffsetToDays = offset;
        }
        break;
      case "Months":
        {
          convertOffsetToDays = offset * 30;
        }
        break;
      case "Weeks":
        {
          convertOffsetToDays = offset * 7;
        }
        break;
      case "Years":
        {
          convertOffsetToDays = offset * 365;
        }
        break;
    }

    let newDate = new Date(date);
    newDate.setDate(newDate.getDate() + Math.ceil(convertOffsetToDays));
    return (
      newDate.getMonth() +
      1 +
      "/" +
      newDate.getDate() +
      "/" +
      newDate.getFullYear()
    );
  }
};

export default ModuleHelpService;
