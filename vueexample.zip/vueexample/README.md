# topuiclient

## Project setup

```vue
npm install
```

### Compiles and hot-reloads for development

```vue
npm run serve
```

### Compiles and minifies for production

```vue
npm run build
```

### Run your unit tests

```vue
npm run test:unit
```

### Lints and fixes files

```vue
npm run lint
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).
