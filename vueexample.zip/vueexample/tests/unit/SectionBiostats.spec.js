import { shallowMount } from "@vue/test-utils";
import SectionBiostats from "@/components/SectionBiostats.vue"; // name of your Vue component

let wrapper;

beforeEach(() => {
  wrapper = shallowMount(SectionBiostats, {
    propsData: {},
    mocks: {},
    stubs: {},
    methods: {}
  });
});

afterEach(() => {
  wrapper.destroy();
});

describe("SectionBiostats", () => {
  test("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });
});
