import { shallowMount } from "@vue/test-utils";
import SectionRegulatorySupport from "@/components/finalcomponents/SectionRegulatorySupport.vue"; // name of your Vue component

let wrapper;

beforeEach(() => {
  wrapper = shallowMount(SectionRegulatorySupport, {
    propsData: {},
    mocks: {},
    stubs: {},
    methods: {}
  });
});

afterEach(() => {
  wrapper.destroy();
});

describe("SectionRegulatorySupport", () => {
  test("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });
});
