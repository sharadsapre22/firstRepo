import { shallowMount } from "@vue/test-utils";
import FileReader from "@/components/FileReader.vue"; // name of your Vue component

let wrapper;

beforeEach(() => {
  wrapper = shallowMount(FileReader, {
    propsData: {},
    mocks: {},
    stubs: {},
    methods: {}
  });
});

afterEach(() => {
  wrapper.destroy();
});

describe("FileReader", () => {
  test("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });
});
