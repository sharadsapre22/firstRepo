import { shallowMount } from "@vue/test-utils";
import SubInfoFraction from "@/components/StudyDesign/SubInfoFraction.vue"; // name of your Vue component

let wrapper;

beforeEach(() => {
  wrapper = shallowMount(SubInfoFraction, {
    propsData: {},
    mocks: {},
    stubs: {},
    methods: {}
  });
});

afterEach(() => {
  wrapper.destroy();
});

describe("SubInfoFraction", () => {
  test("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });
});
