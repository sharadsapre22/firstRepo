import ModuleHelpService from "@/utils/moduleHelpService";

describe("ModuleHelpService", () => {
  test("getItemIndex() function returns an appropriate index on finding particular entry ", () => {
    let jsonObjArr = [
      { designId: "1", designObject: {} },
      { designId: "2", designObject: {} },
      { designId: "3", designObject: {} },
      { designId: "4", designObject: {} }
    ];
    expect(ModuleHelpService.getItemIndex(jsonObjArr, "2")).toBe(1);
  });
  test("getItemIndex() function returns -1 for not finding particular entry ", () => {
    let jsonObjArr = [
      { designId: "1", designObject: {} },
      { designId: "2", designObject: {} },
      { designId: "3", designObject: {} },
      { designId: "4", designObject: {} }
    ];
    expect(ModuleHelpService.getItemIndex(jsonObjArr, "6")).toBe(-1);
  });
  test("getItemIndex() function returns -1 for an empty array ", () => {
    let jsonObjArr = [];
    expect(ModuleHelpService.getItemIndex(jsonObjArr, "6")).toBe(-1);
  });
  test("getItemAtIndex() function returns an appropriate item for a given designId ", () => {
    let jsonObjArr = [
      { designId: "1", designObject: {} },
      { designId: "4", designObject: {} },
      { designId: "2", designObject: {} },
      { designId: "3", designObject: {} }
    ];
    expect(ModuleHelpService.getItemAtIndex(jsonObjArr, "4")).toEqual({
      designId: "4",
      designObject: {}
    });
  });
  test("getItemAtIndex() function returns null for an invalid designId ", () => {
    let jsonObjArr = [
      { designId: "1", designObject: {} },
      { designId: "4", designObject: {} },
      { designId: "2", designObject: {} },
      { designId: "3", designObject: {} }
    ];
    expect(ModuleHelpService.getItemAtIndex(jsonObjArr, "6")).toEqual(
      undefined
    );
  });
  test("getItemAtIndex() function returns null for an empty array ", () => {
    let jsonObjArr = [];
    expect(ModuleHelpService.getItemAtIndex(jsonObjArr, "6")).toEqual(
      undefined
    );
  });
  test("getCurrencyNumberFromNotation() function returns 10 for a given value of 10", () => {
    expect(ModuleHelpService.getCurrencyNumberFromNotation("10")).toEqual("10");
  });
  test("getCurrencyNumberFromNotation() function returns 1000 for a given value of 1k", () => {
    expect(ModuleHelpService.getCurrencyNumberFromNotation("1K")).toEqual(1000);
  });
  test("getCurrencyNumberFromNotation() function returns 1000000 for a given value of 1M", () => {
    expect(ModuleHelpService.getCurrencyNumberFromNotation("1M")).toEqual(
      1000000
    );
  });
  test("getCurrencyNumberFromNotation() function returns 1000000000 for a given value of 1B", () => {
    expect(ModuleHelpService.getCurrencyNumberFromNotation("1B")).toEqual(
      1000000000
    );
  });
  test("getCurrencyNumberFromNotation() function returns 1000000000000 for a given value of 1T", () => {
    expect(ModuleHelpService.getCurrencyNumberFromNotation("1T")).toEqual(
      1000000000000
    );
  });
  test("getCurrencyNosFromCurrencyNotations() function returns 10 for a given value of 10", () => {
    expect(ModuleHelpService.getCurrencyNosFromCurrencyNotations("10")).toEqual(
      "10"
    );
  });
  test("getCurrencyNosFromCurrencyNotations() function returns 1000 for a given value of 1k", () => {
    expect(ModuleHelpService.getCurrencyNosFromCurrencyNotations("1K")).toEqual(
      1000
    );
  });
  test("getCurrencyNosFromCurrencyNotations() function returns 1000000 for a given value of 1M", () => {
    expect(ModuleHelpService.getCurrencyNosFromCurrencyNotations("1M")).toEqual(
      1000000
    );
  });
  test("getCurrencyNosFromCurrencyNotations() function returns 1000000000 for a given value of 1B", () => {
    expect(ModuleHelpService.getCurrencyNosFromCurrencyNotations("1B")).toEqual(
      1000000000
    );
  });
  test("getCurrencyNosFromCurrencyNotations() function returns 1000000000000 for a given value of 1T", () => {
    expect(ModuleHelpService.getCurrencyNosFromCurrencyNotations("1T")).toEqual(
      1000000000000
    );
  });
  test("getCurrencyNosFromCurrencyNotations() function returns 25:450:100 for a given value of 25:450:100", () => {
    expect(
      ModuleHelpService.getCurrencyNosFromCurrencyNotations("25:450:100")
    ).toEqual("25:450:100");
  });
  test("getCurrencyNosFromCurrencyNotations() function returns 25:450:100 for a given value of 25:450:100", () => {
    expect(
      ModuleHelpService.getCurrencyNosFromCurrencyNotations("258:45K:1M")
    ).toEqual("258:45000:1000000");
  });
  test("getCurrencyNosFromCurrencyNotations() function returns 1K:34K:5K for a given value of 1000:34000:5000", () => {
    expect(
      ModuleHelpService.getCurrencyNosFromCurrencyNotations("1K:34K:5K")
    ).toEqual("1000:34000:5000");
  });
  test("getCurrencyNosFromCurrencyNotations() function returns 1K:34B:5M for a given value of 1000:34000000000:5000000", () => {
    expect(
      ModuleHelpService.getCurrencyNosFromCurrencyNotations("1K:34B:5M")
    ).toEqual("1000:34000000000:5000000");
  });
  test("getCurrencyNosFromCurrencyNotations() function returns 345,23,1K:34B:5M,5K for a given value of 1000:34000000000:5000000", () => {
    expect(
      ModuleHelpService.getCurrencyNosFromCurrencyNotations(
        "345,23,1K:34B:5M,5K"
      )
    ).toEqual("345,23,1000:34000000000:5000000,5000");
  });
  test("getRangeMultipleValues() function returns 1,10,5 for a given value of [1,6,10]", () => {
    expect(ModuleHelpService.getRangeMultipleValues(1, 10, 5)).toEqual([
      1,
      6,
      10
    ]);
  });
  test("getRangeMultipleValues() function returns 1,1,1 for a given value of [1]", () => {
    expect(ModuleHelpService.getRangeMultipleValues(1, 1, 1)).toEqual([1]);
  });
  test("getRangeMultipleValues() function returns 1,1 for a given value of [1]", () => {
    expect(ModuleHelpService.getRangeMultipleValues(1, 1)).toEqual([1]);
  });
  test("getRangeMultipleValues() function returns a,f for a given value of undefined", () => {
    expect(ModuleHelpService.getRangeMultipleValues("a", "b", 1)).toEqual(
      undefined
    );
  });
  test("getRangeMultipleValues() function returns a,f,c for a given value of undefined", () => {
    expect(ModuleHelpService.getRangeMultipleValues("a", "b", "c")).toEqual(
      undefined
    );
  });
  test("getRangeMultipleValues() function returns 1000,1000000,100000 for a given value of [1000,101000,201000,301000,401000,501000,601000,701000,801000,901000,1000000]", () => {
    expect(
      ModuleHelpService.getRangeMultipleValues(1000, 1000000, 100000)
    ).toEqual([
      1000,
      101000,
      201000,
      301000,
      401000,
      501000,
      601000,
      701000,
      801000,
      901000,
      1000000
    ]);
  });
  test("getMultipleValues() function returns 1 for a given value of [1]", () => {
    expect(ModuleHelpService.getMultipleValues("1")).toEqual(["1"]);
  });
  test("getMultipleValues() function returns 1,2,3,4,5 for a given value of [1,2,3,4,5]", () => {
    expect(ModuleHelpService.getMultipleValues("1,2,3,4,5")).toEqual([
      1,
      2,
      3,
      4,
      5
    ]);
  });
  test("getMultipleValues() function returns 1.2:2.5:0.5 for a given value of [1.2,1.7,2.2,2.5]", () => {
    expect(ModuleHelpService.getMultipleValues("1.2:2.5:0.5")).toEqual([
      1.2,
      1.7,
      2.2,
      2.5
    ]);
  });
  test("getMultipleValues() function returns 12,23,1:5:1,45,23 for a given value of [12,23,1,2,3,4,5,45,23]", () => {
    expect(ModuleHelpService.getMultipleValues("12,23,1:5:1,45,23")).toEqual([
      12,
      23,
      1,
      2,
      3,
      4,
      5,
      45,
      23
    ]);
  });
});
