import { shallowMount } from "@vue/test-utils";
import DesignAdvisor from "@/views/DesignAdvisor.vue"; // name of your Vue component

let wrapper;

beforeEach(() => {
  wrapper = shallowMount(DesignAdvisor, {
    propsData: {},
    mocks: {},
    stubs: {},
    methods: {}
  });
});

afterEach(() => {
  wrapper.destroy();
});

describe("DesignAdvisor", () => {
  test("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });
});
