import { shallowMount } from "@vue/test-utils";
import SubInterimAnalysis from "@/components/StudyDesign/SubInterimAnalysis.vue"; // name of your Vue component

let wrapper;

beforeEach(() => {
  wrapper = shallowMount(SubInterimAnalysis, {
    propsData: {},
    mocks: {},
    stubs: {},
    methods: {}
  });
});

afterEach(() => {
  wrapper.destroy();
});

describe("SubInterimAnalysis", () => {
  test("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });
});
