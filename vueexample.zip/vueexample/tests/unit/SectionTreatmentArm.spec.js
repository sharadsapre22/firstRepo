import { shallowMount } from "@vue/test-utils";
import SectionTreatmentArm from "@/components/finalcomponents/SectionTreatmentArm.vue"; // name of your Vue component

let wrapper;

beforeEach(() => {
  wrapper = shallowMount(SectionTreatmentArm, {
    propsData: {},
    mocks: {},
    stubs: {},
    methods: {}
  });
});

afterEach(() => {
  wrapper.destroy();
});

describe("SectionTreatmentArm", () => {
  test("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });
});