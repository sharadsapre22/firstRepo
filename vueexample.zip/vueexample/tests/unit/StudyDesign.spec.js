import { shallowMount } from "@vue/test-utils";
import StudyDesign from "@/components/StudyDesign/SectionStudyDesign.vue";
let wrapper;

beforeEach(() => {
  wrapper = shallowMount(StudyDesign, {
    propsData: {
      noofIA: "0",
      percEventsAtIA: "0",
      timeUnit: "Months"
    },
    mocks: {},
    stubs: {},
    methods: {}
  });
});

afterEach(() => {
  wrapper.destroy();
});

describe("Test Section Study Design Component", () => {
  it("test of intermin Analaysis is zero", () => {
    let inputText = wrapper.find('input[type="text"]').value;
    expect(wrapper.props().noofIA).toBe(inputText);
    expect(wrapper.props().timeUnit).toBe("month");
  });
});
