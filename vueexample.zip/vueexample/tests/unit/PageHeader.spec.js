import { shallowMount } from "@vue/test-utils";
import PageHeader from "@/components/PageHeader.vue"; // name of your Vue component

let wrapper;

beforeEach(() => {
  wrapper = shallowMount(PageHeader, {
    propsData: {},
    mocks: {},
    stubs: {},
    methods: {}
  });
});

afterEach(() => {
  wrapper.destroy();
});

describe("PageHeader", () => {
  test("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });
});
