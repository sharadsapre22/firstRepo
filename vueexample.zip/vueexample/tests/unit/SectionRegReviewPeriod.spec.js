import { shallowMount } from "@vue/test-utils";
import SectionRegReviewPeriod from "@/components/finalcomponents/SectionRegReviewPeriod.vue"; // name of your Vue component

let wrapper;

beforeEach(() => {
  wrapper = shallowMount(SectionRegReviewPeriod, {
    propsData: {},
    mocks: {},
    stubs: {},
    methods: {}
  });
});

afterEach(() => {
  wrapper.destroy();
});

describe("SectionRegReviewPeriod", () => {
  test("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });
});
