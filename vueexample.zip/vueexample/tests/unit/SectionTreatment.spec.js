import { shallowMount } from "@vue/test-utils";
import SectionTreatment from "@/components/finalcomponents/SectionTreatment.vue"; // name of your Vue component

let wrapper;

beforeEach(() => {
  wrapper = shallowMount(SectionTreatment, {
    propsData: {},
    mocks: {},
    stubs: {},
    methods: {}
  });
});

afterEach(() => {
  wrapper.destroy();
});

describe("SectionTreatment", () => {
  test("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });
});
