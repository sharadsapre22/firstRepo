import { shallowMount } from "@vue/test-utils";
import SectionSeedParams from "@/components/SectionSeedParams.vue"; // name of your Vue component

let wrapper;

beforeEach(() => {
  wrapper = shallowMount(SectionSeedParams, {
    propsData: {},
    mocks: {},
    stubs: {},
    methods: {}
  });
});

afterEach(() => {
  wrapper.destroy();
});

describe("SectionSeedParams", () => {
  test("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });
});
