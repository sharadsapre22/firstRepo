import { shallowMount } from "@vue/test-utils";
import SubTimeUnit from "@/components/StudyDesign/SubTimeUnit.vue"; // name of your Vue component

let wrapper;

beforeEach(() => {
  wrapper = shallowMount(SubTimeUnit, {
    propsData: {},
    mocks: {},
    stubs: {},
    methods: {}
  });
});

afterEach(() => {
  wrapper.destroy();
});

describe("SubTimeUnit", () => {
  test("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });
});
