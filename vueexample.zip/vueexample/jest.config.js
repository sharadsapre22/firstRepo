module.exports = {
  preset: "@vue/cli-plugin-unit-jest",

  moduleFileExtensions: ["js", "jsx", "json", "vue"],
  transform: {
    "^.+\\.js$": "babel-jest",
    ".*\\.(vue)$": "vue-jest",
    "^.+\\.vue$": "vue-jest",
    ".+\\.(css|styl|less|sass|scss|svg|png|jpg|ttf|woff|woff2)$":
      "jest-transform-stub",
    "^.+\\.jsx?$": "babel-jest"
  },
  snapshotSerializers: ["jest-serializer-vue"],
  collectCoverage: true,
  collectCoverageFrom: [
    "src/**/*.{vue,js,jsx}",
    "!**/node_modules/**",
    "!**/vendor/**",
    "!src/**/coverage/**",
    "!src/**/plugins/**",
    "!src/main.js"
  ],
  testMatch: [
    "**/tests/unit/**/*.spec.(js|jsx|ts|tsx)|**/__tests__/*.(js|jsx|ts|tsx)"
  ],
  transformIgnorePatterns: [`<rootDir>/src/plugins/boostrap-vue.js`],
  moduleNameMapper: {
    "^@/(.*)$": "<rootDir>/src/$1"
  },
  coverageDirectory: "<rootDir>/src/coverage",
  coverageReporters: ["json", "lcov", "text", "clover", "html"]
};
